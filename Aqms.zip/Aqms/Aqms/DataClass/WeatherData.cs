﻿// Decompiled with JetBrains decompiler
// Type: TrusurAQMCilegon2019.DataClass.WeatherLoopData
// Assembly: TrusurAQMCilegon2019, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4B8B87E8-4F91-4F01-A4B6-8776C395B724
// Assembly location: E:\trusur_juara\TrusurAQMCilegon2019\TrusurAQMCilegon2019.exe

namespace Aqms.DataClass
{
    public class WeatherData
    {
        public double pressure = -1.0;
        public double ws = -1.0;
        public double wd = -1.0;
        public double temp = -1.0;
        public double sr = -1.0;
        public double humidity = -1.0;
        public double rain_intensity = -1.0;
        public double day_rain = -1.0;
    }
}