﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Aqms.DataClass;
using Aqms.Functions;
using LabJack;
using Newtonsoft.Json.Linq;
using MySql.Data.MySqlClient;

namespace Aqms
{
    public partial class FrmMain : Form
    {
        public void saving30menit(double h2s, double cs2, double ws, double wd, double humidity, double temperature, double pressure, double sr, double rain_intensity)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection("host=127.0.0.1;port=3306;user id=root;password=root;database=cams;"))
                {
                    mySqlConnection.Open();
                    using (MySqlCommand command = mySqlConnection.CreateCommand())
                    {
                        command.CommandText = "INSERT INTO cams_data (id_stasiun,waktu,h2s,cs2,ws,wd,humidity,temperature,pressure) VALUES ('SOLO_GUPIT',NOW(),@h2s,@cs2,@ws,@wd,@humidity,@temperature,@pressure);";
                        command.Parameters.AddWithValue("@h2s", (object)this.tot_h2s);
                        command.Parameters.AddWithValue("@cs2", (object)this.tot_cs2);
                        command.Parameters.AddWithValue("@ws", (object)this.tot_ws);
                        command.Parameters.AddWithValue("@wd", (object)this.tot_wd);
                        command.Parameters.AddWithValue("@humidity", (object)this.tot_humidity);
                        command.Parameters.AddWithValue("@temperature", (object)this.tot_temperature);
                        command.Parameters.AddWithValue("@pressure", (object)this.tot_pressure);
                        //command.Parameters.AddWithValue("@sr", (object)this.tot_sr);
                        //command.Parameters.AddWithValue("@rain_intensity", (object)this.tot_rain_intensity);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error DB: " + ex.Message);
            }
        }

        int handle = 0;
        private string[] arr = new string[16]
        {
          "Utara",
          "NNE",
          "Timur Laut",
          "ENE",
          "Timur",
          "ESE",
          "Tenggara",
          "SSE",
          "Selatan",
          "SSW",
          "Barat Daya",
          "WSW",
          "Barat",
          "WNW",
          "Barat Laut",
          "NNW"
        };
        private static readonly DateTime Jan1st1970 = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        public Konfigurasi konfigurasi;
        public CalibrationFactor calibrationFactor;
        public GasData H2S_DATA;
        public Controller controller;
        public GasData Cs2_DATA;
        private int currentUnit = 0;
        private Random random = new Random();
        private double wd;
        private double kec_angin;
        private double temperature;
        private double tekanan;
        private double kelembaban;
        private object lblKecepatanAngin;

        public double tot_h2s = 0;
        public double tot_cs2 = 0;
        public double tot_ws = 0;
        public double tot_wd = 0;
        public double tot_humidity = 0;
        public double tot_temperature = 0;
        public double tot_pressure = 0;
        public double tot_sr = 0;
        public double tot_rain_intensity = 0;

        public int i_h2s = 0;
        public int i_cs2 = 0;
        public int i_ws = 0;
        public int i_wd = 0;
        public int i_humidity = 0;
        public int i_temperature = 0;
        public int i_pressure = 0;
        public int i_sr = 0;
        public int i_rain_intensity = 0;

        private bool weatherWorkerIsWorking = true;

        private WeatherData weatherData = new WeatherData();

        private bool weather_simulation = true;
        private BackgroundWorker weatherWorker;
        private BackgroundWorker senderWorker;
        private BackgroundWorker mqttWorker;
        private BackgroundWorker unsentSenderWorker;
        private BackgroundWorker socketWorker;
        public FrmMain()
        {
            InitializeComponent();
            timer.Start();

            this.BackgroundImage = Properties.Resources.dark_textures_wallpapers_25193_6612675;
            this.BackgroundImageLayout = ImageLayout.Stretch;
            ImgLogo.BackColor = Color.Transparent;
            lblLogo.BackColor = Color.Transparent;
            lblTime.BackColor = Color.Transparent;
            lblDate.BackColor = Color.Transparent;

            pctServer.BackColor = Color.Transparent;
            pctGlobe.BackColor = Color.Transparent;
            lblServer.BackColor = Color.Transparent;
            lblInternet.BackColor = Color.Transparent;

            lblTime.Text = DateTime.Now.ToLongTimeString();
            lblDate.Text = DateTime.Now.ToLongDateString();

            this.getWeather();

            //this.weatherWorker.RunWorkerAsync();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            this.calibrationFactor = new CalibrationFactor();
            this.controller = new Controller(this);

            this.cmbH2s.Items.Add("Ppb");
            this.cmbH2s.Items.Add("Ppm");
            this.cmbH2s.Items.Add("Ug/m3");
            cmbH2s.SelectedItem = "Ppm";

            this.cmbCs2.Items.Add("Ppb");
            this.cmbCs2.Items.Add("Ppm");
            this.cmbCs2.Items.Add("Ug/m3");

            this.H2S_DATA = new GasData(this);
            this.Cs2_DATA = new GasData(this);

            cmbCs2.SelectedItem = "Ppm";

            //this.TopMost = true;

            //this.FormBorderStyle = FormBorderStyle.None;

            //this.WindowState = FormWindowState.Maximized;
            //port1.Open();
        }
         
        private void PictureBox1_Click(object sender, EventArgs e)
        {

        }
        private string degToCompass(float num)
        {
            return this.arr[(int)((double)num / 22.5 + 0.5) % 16];
        }

        void getWeather()
        {
            this.readWS();
        }
        private void getWeatherX()
        {
            try
            {
                JObject jobject1 = JObject.Parse(new WebClient().DownloadString("http://api.openweathermap.org/data/2.5/weather?id=1626498&appid=b4c11b6e68c514342714cb92bf4ef2ff&units=metric"));
                JObject jobject2 = JObject.Parse(jobject1["main"].ToString());
                JObject jobject3 = JObject.Parse(jobject1["wind"].ToString());
                this.wd = Convert.ToDouble(jobject3["deg"].ToString());
                this.kec_angin = Convert.ToDouble(jobject3["speed"].ToString());
                this.temperature = Convert.ToDouble(jobject2["temp"].ToString());
                this.tekanan = Convert.ToDouble(jobject2["pressure"].ToString());
                this.kelembaban = Convert.ToDouble(jobject2["humidity"].ToString());

                tot_ws += this.kec_angin;
                tot_wd += this.wd;
                tot_temperature += this.temperature;
                tot_pressure += this.tekanan;
                tot_humidity += this.kelembaban;
                i_ws++;
                i_wd++;
                i_temperature++;
                i_pressure++;
                i_humidity++;

                this.lblValSpeed.InvokeIfRequired((MethodInvoker)(() =>
                {
                    this.lblValTemperature.Text = string.Format("{0:0.0}", (object)this.temperature) + "°";
                    this.lblValSpeed.Text = string.Format("{0:0.0}", (object)this.kec_angin);
                    this.lblValDirection.Text = string.Format("{0:0.0}", (object)this.wd) + "°";
                    this.lblDirections.Text = this.degToCompass((float)this.wd);
                    this.lblValPressure.Text = string.Format("{0:0.0}", (object)this.tekanan);
                    this.lblKelembaban.Text = this.kelembaban + "";
                 }));
            }
            catch (Exception ex)
            {
                Console.WriteLine("GetWeather: " + ex.Message);
            }
        }
        private void Timer_Tick(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToLongTimeString();

            double voltage1 = -1.0;
            double voltage2 = -1.0;

            try
            {

                LJM.OpenS("ANY", "ANY", "ANY", ref handle);



                string name = "AIN0";

                string name1 = "AIN1";
                LJM.StartInterval(1, 1000000);
                LJM.eReadName(this.handle, name, ref voltage1);
                LJM.eReadName(this.handle, name1, ref voltage2);
                double num8;
                double num9;
                tot_h2s += this.H2S_DATA.getValue(2);
                i_h2s++;

                tot_cs2 += this.Cs2_DATA.getValue(2);
                i_cs2++;
                switch (cmbH2s.SelectedItem.ToString().Trim())
                {
                    case "Ppb":
                        //double H2sPpb = voltage1 * 3.2 * 1000;
                        //lblValH2s.Text = H2sPpb.ToString("F6") + " Ppb";
                        this.H2S_DATA.setValue(voltage1, 6);
                        num8 = this.H2S_DATA.getValue(1);
                        lblValH2s.Text = num8.ToString();
                        break;
                    case "Ug/m3":
                        //double H2sUgm3 = voltage1 * 3.2 * 0.670 * 1000;
                        //lblValH2s.Text = H2sUgm3.ToString("F6") + " Ug/m3";
                        this.H2S_DATA.setValue(voltage1, 6);
                        num8 = this.H2S_DATA.getValue(2);
                        lblValH2s.Text = num8.ToString();
                        break;
                    case "Ppm":
                        if(voltage1 != -1.0)
                        {
                            //double H2sPpm = voltage1 * 3.2;
                            //lblValH2s.Text = H2sPpm.ToString("F6") + " Ppm";

                            this.H2S_DATA.setValue(voltage1, 6);
                            num8 = this.H2S_DATA.getValue(0);
                            lblValH2s.Text = num8.ToString();
                        }
                        break;
                    default:
                        if (voltage1 != -1.0)
                        {
                            //double H2sPpm = voltage1 * 3.2;
                            //lblValH2s.Text = H2sPpm.ToString("F6") + " Ppm";

                            this.H2S_DATA.setValue(voltage1, 6);
                            num8 = this.H2S_DATA.getValue(0);
                            lblValH2s.Text = num8.ToString();
                        }
                        break;
                }
                switch (cmbCs2.SelectedItem.ToString().Trim())
                {
                    case "Ppb":
                        double Cs2Ppb = voltage2 * 1.2 * 1000;
                        //lblValCs2.Text = Cs2Ppb.ToString("F6") + " Ppb";
                        this.Cs2_DATA.setValue(voltage2, 7);
                        num9 = this.Cs2_DATA.getValue(1);
                        lblValCs2.Text = num9.ToString();
                        break;
                    case "Ug/m3":
                        double Cs2Ugm3 = voltage2 * 1.2 * 0.32 * 1000;
                        //lblValCs2.Text = Cs2Ugm3.ToString("F6") + " Ug/m3";
                        this.Cs2_DATA.setValue(voltage2, 7);
                        num9 = this.Cs2_DATA.getValue(2);
                        lblValCs2.Text = num9.ToString();
                        break;

                    case "Ppm":
                        //double Cs2Ppm = voltage2 * 1.2;
                        //lblValCs2.Text = Cs2Ppm.ToString("F6") + " Ppm";

                        this.Cs2_DATA.setValue(voltage2, 7);
                        num9 = this.Cs2_DATA.getValue(0);
                        lblValCs2.Text = num9.ToString();
                        break;
                    default:
                        this.Cs2_DATA.setValue(voltage2, 7);
                        num9 = this.Cs2_DATA.getValue(0);
                        lblValCs2.Text = num9.ToString();

                        break;
                }
            }
            catch (LJM.LJMException ex)
            {
                showErrorMessage(ex);
            }

            LJM.CloseAll();  //Close all handlesx
            
            //timer.Start();
        }
        private void weatherWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            long num1 = FrmMain.CurrentTimeMillis();
            while (this.weatherWorkerIsWorking)
            {
                Thread.Sleep(10);
                long num2 = FrmMain.CurrentTimeMillis();
                if (num2 - num1 > 3000L)
                {
                    if (!this.weather_simulation)
                        this.readWS();
                    num1 = num2;
                }
                if (this.weather_simulation && num2 - num1 > 900000L)
                {
                    this.getWeather();
                    num1 = num2;
                }
                if (!this.weatherWorkerIsWorking)
                    break;
            }
        }
        private void readWS()
        {
            SerialPort thePort = this.OpenWS();
            if (thePort == null)
                return;
            if (this.wakeWS(thePort))
            {
                WeatherLoopData weatherLoopData = new WeatherLoopData();
                byte[] loopByteArray = this.Retrieve_Serial_Command(thePort, "LOOP 1", 95);
                if (loopByteArray != null)
                {
                    this.weatherData = !weatherLoopData.Load(loopByteArray) ? new WeatherData() : weatherLoopData.getData();
                }
                else
                {
                    Debug.WriteLine("Connect to WS", "Lost Connection to WS");
                    this.weatherData = new WeatherData();
                }
            }
            else
            {
                Debug.WriteLine("Connect to WS", "Cannot Connect to Vantage Weatherstation");
                this.weatherData = new WeatherData();
            }
            this.lblValSpeed.InvokeIfRequired((MethodInvoker)(() =>
            {
                this.lblValDirection.Text = string.Concat((object)this.weatherData.wd);
                this.lblDirections.Text = this.degToCompass((float)this.weatherData.wd);
                this.lblValCurahHujan.Text = string.Concat((object)this.weatherData.day_rain);
                this.lblValSpeed.Text = string.Concat((object)this.weatherData.ws);
                this.lblKelembaban.Text = string.Concat((object)this.weatherData.humidity);
                this.lblValSolarRadiation.Text = string.Concat((object)this.weatherData.sr);
                this.lblValPressure.Text = string.Concat((object)this.weatherData.pressure);
                this.lblValTemperature.Text = string.Concat((object)this.weatherData.temp);
            }));
            thePort.Close();
        }
        private byte[] Retrieve_Serial_Command(
          SerialPort thePort,
          string commandString,
          int returnLength)
            {
                bool flag = false;
                int num1 = 6;
                int num2 = 1;
                int num3 = 4;
                try
                {
                    thePort.DiscardInBuffer();
                    thePort.DiscardOutBuffer();
                    for (; !flag && num2 < num3; ++num2)
                    {
                        thePort.WriteLine(commandString);
                        Thread.Sleep(2000);
                        while (thePort.BytesToRead > 0 && !flag)
                        {
                            if (thePort.ReadChar() == num1)
                                flag = true;
                        }
                    }
                    if (num2 == num3)
                        return (byte[])null;
                    byte[] buffer = new byte[returnLength];
                    while (thePort.BytesToRead <= buffer.Length)
                        Thread.Sleep(200);
                    thePort.Read(buffer, 0, returnLength);
                    return buffer;
                }
                catch (Exception ex)
                {
                    this.sendMessage("Retrieve Serial Command WS: " + ex.Message);
                    return (byte[])null;
                }
            }
        public void sendMessage(string message)
        {
            //this.lblError.InvokeIfRequired((MethodInvoker)(() =>
            //{
            //    this.lblError.AppendText(message + Environment.NewLine);
            //    if (this.lblError.Lines.Length <= 1000)
            //        return;
            //    this.lblError.Clear();
            //}));
        }
        private bool wakeWS(SerialPort thePort)
        {
            int num1 = 1;
            int num2 = 4;
            try
            {
                thePort.DiscardInBuffer();
                thePort.DiscardOutBuffer();
                thePort.WriteLine("");
                Thread.Sleep(300);
                for (; thePort.BytesToRead == 0 && num1 < num2; ++num1)
                {
                    thePort.WriteLine("");
                    Thread.Sleep(500);
                }
                if (num1 >= num2)
                    return false;
                thePort.DiscardInBuffer();
                return true;
            }
            catch (Exception ex)
            {
                this.sendMessage("Wake WS: " + ex.Message);
                return false;
            }
        }
        private SerialPort OpenWS()
        {
            try
            {
                SerialPort serialPort = new SerialPort("COM5", 19200, Parity.None, 8, StopBits.One);
                serialPort.ReadTimeout = 2500;
                serialPort.WriteTimeout = 2500;
                serialPort.DtrEnable = true;
                serialPort.Open();
                return serialPort;
            }
            catch (Exception ex)
            {
                if (!ex.Message.Contains("denied"))
                    this.sendMessage("Open Serial WS: " + ex.Message);
                return (SerialPort)null;
            }
        }
        public static long CurrentTimeMillis()
        {
            return (long)(DateTime.UtcNow - FrmMain.Jan1st1970).TotalMilliseconds;
        }
        public double GetRandomNumber(double minimum, double maximum, int round)
        {
            return Math.Round(this.random.NextDouble() * (maximum - minimum) + minimum, round);
        }
        private void LblValH2s_Click(object sender, EventArgs e)
        {

        }
        public void showErrorMessage(LJM.LJMException e)
        {
            Console.Out.WriteLine("LJMException: " + e.ToString());
            Console.Out.WriteLine(e.StackTrace);
        }
        private void Button1_Click(object sender, EventArgs e)
        {
            //int num = (int)new FrmCalibration(this).ShowDialog();
            //port1.Write("b");
            //if (port1.IsOpen)
            //{
            //    port1.Write("b");
            int num = (int)new FrmCalibration(this).ShowDialog();
            //    //MessageBox.Show("sukes konek port");
            //}
        }

        private void Button1_Click_1(object sender, EventArgs e)
        {

        }

        private void Label5_Click(object sender, EventArgs e)
        {

        }

        private void Label11_Click(object sender, EventArgs e)
        {

        }

        private void Label10_Click(object sender, EventArgs e)
        {

        }

        private void Label13_Click(object sender, EventArgs e)
        {

        }

        private void LblServer_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.getWeather();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            tot_h2s = tot_h2s / i_h2s;
            tot_cs2 = tot_cs2 / i_cs2;
            tot_ws = tot_ws / i_ws;
            tot_wd = tot_wd / i_wd;
            tot_humidity = tot_humidity / i_humidity;
            tot_temperature = tot_temperature / i_temperature;
            tot_pressure = tot_pressure / i_pressure;
            tot_sr = tot_sr / i_sr;
            tot_rain_intensity = tot_rain_intensity / i_rain_intensity;
            this.saving30menit(tot_h2s,tot_cs2,tot_ws,tot_wd,tot_humidity,tot_temperature,tot_pressure,tot_sr,tot_rain_intensity);
            tot_h2s = 0;
            tot_cs2 = 0;
            tot_ws = 0;
            tot_wd = 0;
            tot_humidity = 0;
            tot_temperature = 0;
            tot_pressure = 0;
            tot_sr = 0;
            tot_rain_intensity = 0;
            i_h2s = 0;
            i_cs2 = 0;
            i_ws = 0;
            i_wd = 0;
            i_humidity = 0;
            i_temperature = 0;
            i_pressure = 0;
            i_sr = 0;
            i_rain_intensity = 0;

        }
    }
}
