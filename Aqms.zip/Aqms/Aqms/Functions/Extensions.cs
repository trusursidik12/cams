﻿// Decompiled with JetBrains decompiler
// Type: TrusurAQMCilegon2019.Functions.Extensions
// Assembly: TrusurAQMCilegon2019, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4B8B87E8-4F91-4F01-A4B6-8776C395B724
// Assembly location: E:\trusur_juara\TrusurAQMCilegon2019\TrusurAQMCilegon2019.exe

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Windows.Forms;

public static class Extensions
{
    public static void InvokeIfRequired(this ISynchronizeInvoke obj, MethodInvoker action)
    {
        if (obj.InvokeRequired)
        {
            object[] args = new object[0];
            obj.Invoke(action, args);
        }
        else
        {
            action();
        }
    }

    public static string Truncate(this string value, int maxLength)
    {
        if (string.IsNullOrEmpty(value))
        {
            return value;
        }
        return (value.Length <= maxLength) ? value : value.Substring(0, maxLength);
    }

    public static double FindMode(List<double> doubleList)
    {
        if (doubleList.Count > 0)
        {
            try
            {
                var source = (from values in doubleList
                              group values by values into valueCluster
                              select new
                              {
                                  Value = valueCluster.Key,
                                  Occurrence = valueCluster.Count()
                              }).ToList();
                int maxOccurrence = source.Max(g => g.Occurrence);
                IEnumerable<double> source2 = from x in source
                                              where x.Occurrence == maxOccurrence && maxOccurrence > 1
                                              select x.Value;
                if (source2.Count() == 1)
                {
                    return source2.FirstOrDefault();
                }
                if (source2.Count() > 1)
                {
                    return Math.Round(source2.Average());
                }
                return Math.Round(doubleList.Average());
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error when calculating mode: " + ex.Message);
                return -1.0;
            }
        }
        return -1.0;
    }
}
