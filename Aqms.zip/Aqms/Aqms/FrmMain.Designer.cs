﻿using System.ComponentModel;

namespace Aqms
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblLogo = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.lblDate = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnSatuan = new System.Windows.Forms.Button();
            this.lblJenis = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cmbCs2 = new System.Windows.Forms.ComboBox();
            this.cmbH2s = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblValCs2 = new System.Windows.Forms.Label();
            this.lblCs2 = new System.Windows.Forms.Label();
            this.lblValH2s = new System.Windows.Forms.Label();
            this.lblH2s = new System.Windows.Forms.Label();
            this.lblServer = new System.Windows.Forms.Label();
            this.lblInternet = new System.Windows.Forms.Label();
            this.btnData = new System.Windows.Forms.Button();
            this.btnCalibration = new System.Windows.Forms.Button();
            this.pctServer = new System.Windows.Forms.PictureBox();
            this.pctGlobe = new System.Windows.Forms.PictureBox();
            this.ImgLogo = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.lblKelembaban = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lblValSolarRadiation = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.lblValPressure = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblDirections = new System.Windows.Forms.Label();
            this.lblValTemperature = new System.Windows.Forms.Label();
            this.lblValDirection = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblValSpeed = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.port1 = new System.IO.Ports.SerialPort(this.components);
            this.weatherWork = new System.ComponentModel.BackgroundWorker();
            this.weatherWorker = new System.ComponentModel.BackgroundWorker();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.lblValCurahHujan = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctServer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctGlobe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImgLogo)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblLogo
            // 
            this.lblLogo.AutoSize = true;
            this.lblLogo.Font = new System.Drawing.Font("Sitka Text", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogo.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblLogo.Location = new System.Drawing.Point(121, 30);
            this.lblLogo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLogo.Name = "lblLogo";
            this.lblLogo.Size = new System.Drawing.Size(226, 68);
            this.lblLogo.TabIndex = 0;
            this.lblLogo.Text = "TRUSUR";
            this.lblLogo.Click += new System.EventHandler(this.Label1_Click);
            // 
            // lblTime
            // 
            this.lblTime.AutoSize = true;
            this.lblTime.Font = new System.Drawing.Font("Sitka Text", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblTime.Location = new System.Drawing.Point(779, -5);
            this.lblTime.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTime.Name = "lblTime";
            this.lblTime.Padding = new System.Windows.Forms.Padding(0, 0, 0, 12);
            this.lblTime.Size = new System.Drawing.Size(186, 99);
            this.lblTime.TabIndex = 2;
            this.lblTime.Text = "Time";
            // 
            // lblDate
            // 
            this.lblDate.AutoSize = true;
            this.lblDate.Font = new System.Drawing.Font("Sitka Text", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDate.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblDate.Location = new System.Drawing.Point(747, 68);
            this.lblDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDate.Name = "lblDate";
            this.lblDate.Size = new System.Drawing.Size(98, 49);
            this.lblDate.TabIndex = 3;
            this.lblDate.Text = "Date";
            // 
            // timer
            // 
            this.timer.Enabled = true;
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.Timer_Tick);
            // 
            // panel1
            // 
            this.panel1.AutoSize = true;
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.btnSatuan);
            this.panel1.Controls.Add(this.lblJenis);
            this.panel1.Font = new System.Drawing.Font("Sitka Text", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.panel1.Location = new System.Drawing.Point(16, 130);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(460, 48);
            this.panel1.TabIndex = 4;
            // 
            // btnSatuan
            // 
            this.btnSatuan.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnSatuan.Location = new System.Drawing.Point(341, 4);
            this.btnSatuan.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSatuan.Name = "btnSatuan";
            this.btnSatuan.Size = new System.Drawing.Size(115, 39);
            this.btnSatuan.TabIndex = 1;
            this.btnSatuan.Text = "Satuan";
            this.btnSatuan.UseVisualStyleBackColor = true;
            // 
            // lblJenis
            // 
            this.lblJenis.AutoSize = true;
            this.lblJenis.Location = new System.Drawing.Point(5, 5);
            this.lblJenis.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblJenis.Name = "lblJenis";
            this.lblJenis.Size = new System.Drawing.Size(200, 29);
            this.lblJenis.TabIndex = 0;
            this.lblJenis.Text = "Partikulat Dan Gas";
            this.lblJenis.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel2.Controls.Add(this.cmbCs2);
            this.panel2.Controls.Add(this.cmbH2s);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.lblValCs2);
            this.panel2.Controls.Add(this.lblCs2);
            this.panel2.Controls.Add(this.lblValH2s);
            this.panel2.Controls.Add(this.lblH2s);
            this.panel2.Location = new System.Drawing.Point(16, 175);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(459, 286);
            this.panel2.TabIndex = 5;
            // 
            // cmbCs2
            // 
            this.cmbCs2.FormattingEnabled = true;
            this.cmbCs2.Location = new System.Drawing.Point(299, 164);
            this.cmbCs2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbCs2.Name = "cmbCs2";
            this.cmbCs2.Size = new System.Drawing.Size(141, 24);
            this.cmbCs2.TabIndex = 8;
            // 
            // cmbH2s
            // 
            this.cmbH2s.FormattingEnabled = true;
            this.cmbH2s.Location = new System.Drawing.Point(299, 52);
            this.cmbH2s.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cmbH2s.Name = "cmbH2s";
            this.cmbH2s.Size = new System.Drawing.Size(141, 24);
            this.cmbH2s.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(63, 240);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 35);
            this.label1.TabIndex = 6;
            this.label1.Text = "CAMS GUPIT";
            // 
            // lblValCs2
            // 
            this.lblValCs2.AutoSize = true;
            this.lblValCs2.Font = new System.Drawing.Font("Sitka Text", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValCs2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblValCs2.Location = new System.Drawing.Point(93, 145);
            this.lblValCs2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblValCs2.Name = "lblValCs2";
            this.lblValCs2.Size = new System.Drawing.Size(163, 53);
            this.lblValCs2.TabIndex = 4;
            this.lblValCs2.Text = "0.01234";
            this.lblValCs2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblCs2
            // 
            this.lblCs2.AutoSize = true;
            this.lblCs2.Font = new System.Drawing.Font("Sitka Text", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCs2.Location = new System.Drawing.Point(5, 148);
            this.lblCs2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCs2.Name = "lblCs2";
            this.lblCs2.Size = new System.Drawing.Size(85, 49);
            this.lblCs2.TabIndex = 3;
            this.lblCs2.Text = "CS2";
            // 
            // lblValH2s
            // 
            this.lblValH2s.AutoSize = true;
            this.lblValH2s.Font = new System.Drawing.Font("Sitka Text", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValH2s.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.lblValH2s.Location = new System.Drawing.Point(93, 33);
            this.lblValH2s.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblValH2s.Name = "lblValH2s";
            this.lblValH2s.Size = new System.Drawing.Size(163, 53);
            this.lblValH2s.TabIndex = 1;
            this.lblValH2s.Text = "0.01234";
            this.lblValH2s.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblValH2s.Click += new System.EventHandler(this.LblValH2s_Click);
            // 
            // lblH2s
            // 
            this.lblH2s.AutoSize = true;
            this.lblH2s.Font = new System.Drawing.Font("Sitka Text", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblH2s.Location = new System.Drawing.Point(5, 36);
            this.lblH2s.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblH2s.Name = "lblH2s";
            this.lblH2s.Size = new System.Drawing.Size(90, 49);
            this.lblH2s.TabIndex = 0;
            this.lblH2s.Text = "H2S";
            // 
            // lblServer
            // 
            this.lblServer.AutoSize = true;
            this.lblServer.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblServer.Location = new System.Drawing.Point(892, 491);
            this.lblServer.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblServer.Name = "lblServer";
            this.lblServer.Size = new System.Drawing.Size(154, 17);
            this.lblServer.TabIndex = 8;
            this.lblServer.Text = "SERVER CONNECTED";
            this.lblServer.Click += new System.EventHandler(this.LblServer_Click);
            // 
            // lblInternet
            // 
            this.lblInternet.AutoSize = true;
            this.lblInternet.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.lblInternet.Location = new System.Drawing.Point(892, 527);
            this.lblInternet.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblInternet.Name = "lblInternet";
            this.lblInternet.Size = new System.Drawing.Size(135, 17);
            this.lblInternet.TabIndex = 9;
            this.lblInternet.Text = "INTERNET ACCESS";
            // 
            // btnData
            // 
            this.btnData.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnData.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnData.Image = global::Aqms.Properties.Resources.database__1_;
            this.btnData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnData.Location = new System.Drawing.Point(219, 491);
            this.btnData.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnData.Name = "btnData";
            this.btnData.Size = new System.Drawing.Size(115, 52);
            this.btnData.TabIndex = 10;
            this.btnData.Text = "Data";
            this.btnData.UseVisualStyleBackColor = true;
            // 
            // btnCalibration
            // 
            this.btnCalibration.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalibration.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnCalibration.Image = global::Aqms.Properties.Resources.calibration_mark__1_;
            this.btnCalibration.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCalibration.Location = new System.Drawing.Point(9, 491);
            this.btnCalibration.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCalibration.Name = "btnCalibration";
            this.btnCalibration.Size = new System.Drawing.Size(201, 52);
            this.btnCalibration.TabIndex = 2;
            this.btnCalibration.Text = "     Kalibrasi & Konfigurasi";
            this.btnCalibration.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCalibration.UseVisualStyleBackColor = true;
            this.btnCalibration.Click += new System.EventHandler(this.Button1_Click);
            // 
            // pctServer
            // 
            this.pctServer.Image = global::Aqms.Properties.Resources.network__1_;
            this.pctServer.Location = new System.Drawing.Point(851, 482);
            this.pctServer.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pctServer.Name = "pctServer";
            this.pctServer.Size = new System.Drawing.Size(32, 31);
            this.pctServer.TabIndex = 7;
            this.pctServer.TabStop = false;
            // 
            // pctGlobe
            // 
            this.pctGlobe.Image = global::Aqms.Properties.Resources.globe__1_;
            this.pctGlobe.Location = new System.Drawing.Point(851, 521);
            this.pctGlobe.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.pctGlobe.Name = "pctGlobe";
            this.pctGlobe.Size = new System.Drawing.Size(32, 31);
            this.pctGlobe.TabIndex = 6;
            this.pctGlobe.TabStop = false;
            // 
            // ImgLogo
            // 
            this.ImgLogo.Image = global::Aqms.Properties.Resources.logotrusur;
            this.ImgLogo.Location = new System.Drawing.Point(16, 15);
            this.ImgLogo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.ImgLogo.Name = "ImgLogo";
            this.ImgLogo.Size = new System.Drawing.Size(108, 101);
            this.ImgLogo.TabIndex = 1;
            this.ImgLogo.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.panel3.Controls.Add(this.lblValCurahHujan);
            this.panel3.Controls.Add(this.label22);
            this.panel3.Controls.Add(this.lblKelembaban);
            this.panel3.Controls.Add(this.label20);
            this.panel3.Controls.Add(this.lblValSolarRadiation);
            this.panel3.Controls.Add(this.label15);
            this.panel3.Controls.Add(this.label13);
            this.panel3.Controls.Add(this.lblValPressure);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.lblDirections);
            this.panel3.Controls.Add(this.lblValTemperature);
            this.panel3.Controls.Add(this.lblValDirection);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.lblValSpeed);
            this.panel3.Location = new System.Drawing.Point(496, 177);
            this.panel3.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(555, 286);
            this.panel3.TabIndex = 8;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Sitka Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label22.Location = new System.Drawing.Point(423, 228);
            this.label22.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(33, 29);
            this.label22.TabIndex = 17;
            this.label22.Text = "%";
            // 
            // lblKelembaban
            // 
            this.lblKelembaban.AutoSize = true;
            this.lblKelembaban.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblKelembaban.Location = new System.Drawing.Point(428, 182);
            this.lblKelembaban.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblKelembaban.Name = "lblKelembaban";
            this.lblKelembaban.Size = new System.Drawing.Size(24, 35);
            this.lblKelembaban.TabIndex = 16;
            this.lblKelembaban.Text = "-";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Sitka Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label20.Location = new System.Drawing.Point(225, 228);
            this.label20.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(97, 29);
            this.label20.TabIndex = 15;
            this.label20.Text = "Watt/m2";
            // 
            // lblValSolarRadiation
            // 
            this.lblValSolarRadiation.AutoSize = true;
            this.lblValSolarRadiation.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValSolarRadiation.Location = new System.Drawing.Point(260, 182);
            this.lblValSolarRadiation.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblValSolarRadiation.Name = "lblValSolarRadiation";
            this.lblValSolarRadiation.Size = new System.Drawing.Size(24, 35);
            this.lblValSolarRadiation.TabIndex = 14;
            this.lblValSolarRadiation.Text = "-";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Sitka Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label15.Location = new System.Drawing.Point(57, 228);
            this.label15.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(93, 29);
            this.label15.TabIndex = 13;
            this.label15.Text = "Mm/jam";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Sitka Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label13.Location = new System.Drawing.Point(435, 65);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(64, 29);
            this.label13.TabIndex = 11;
            this.label13.Text = "MBar";
            this.label13.Click += new System.EventHandler(this.Label13_Click);
            // 
            // lblValPressure
            // 
            this.lblValPressure.AutoSize = true;
            this.lblValPressure.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValPressure.Location = new System.Drawing.Point(424, 14);
            this.lblValPressure.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblValPressure.Name = "lblValPressure";
            this.lblValPressure.Size = new System.Drawing.Size(24, 35);
            this.lblValPressure.TabIndex = 9;
            this.lblValPressure.Text = "-";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Sitka Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label7.Location = new System.Drawing.Point(307, 65);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(79, 29);
            this.label7.TabIndex = 8;
            this.label7.Text = "Celcius";
            // 
            // lblDirections
            // 
            this.lblDirections.AutoSize = true;
            this.lblDirections.Font = new System.Drawing.Font("Sitka Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDirections.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lblDirections.Location = new System.Drawing.Point(201, 66);
            this.lblDirections.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDirections.Name = "lblDirections";
            this.lblDirections.Size = new System.Drawing.Size(48, 29);
            this.lblDirections.TabIndex = 5;
            this.lblDirections.Text = "NW";
            // 
            // lblValTemperature
            // 
            this.lblValTemperature.AutoSize = true;
            this.lblValTemperature.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValTemperature.Location = new System.Drawing.Point(319, 15);
            this.lblValTemperature.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblValTemperature.Name = "lblValTemperature";
            this.lblValTemperature.Size = new System.Drawing.Size(24, 35);
            this.lblValTemperature.TabIndex = 6;
            this.lblValTemperature.Text = "-";
            this.lblValTemperature.Click += new System.EventHandler(this.Label10_Click);
            // 
            // lblValDirection
            // 
            this.lblValDirection.AutoSize = true;
            this.lblValDirection.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValDirection.Location = new System.Drawing.Point(189, 16);
            this.lblValDirection.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblValDirection.Name = "lblValDirection";
            this.lblValDirection.Size = new System.Drawing.Size(24, 35);
            this.lblValDirection.TabIndex = 3;
            this.lblValDirection.Text = "-";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Sitka Text", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label6.Location = new System.Drawing.Point(48, 65);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(88, 29);
            this.label6.TabIndex = 2;
            this.label6.Text = "Km/jam";
            // 
            // lblValSpeed
            // 
            this.lblValSpeed.AutoSize = true;
            this.lblValSpeed.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValSpeed.Location = new System.Drawing.Point(71, 15);
            this.lblValSpeed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblValSpeed.Name = "lblValSpeed";
            this.lblValSpeed.Size = new System.Drawing.Size(24, 35);
            this.lblValSpeed.TabIndex = 0;
            this.lblValSpeed.Text = "-";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.SteelBlue;
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Font = new System.Drawing.Font("Sitka Text", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel4.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.panel4.Location = new System.Drawing.Point(496, 130);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(555, 48);
            this.panel4.TabIndex = 7;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(436, 16);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(67, 20);
            this.label12.TabIndex = 10;
            this.label12.Text = "Tekanan";
            this.label12.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(31, 15);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(126, 20);
            this.label9.TabIndex = 0;
            this.label9.Text = "Kecepatan Angin";
            this.label9.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(185, 16);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 20);
            this.label5.TabIndex = 4;
            this.label5.Text = "Arah Angin";
            this.label5.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label5.Click += new System.EventHandler(this.Label5_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(303, 16);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 20);
            this.label11.TabIndex = 7;
            this.label11.Text = "Temperature";
            this.label11.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            this.label11.Click += new System.EventHandler(this.Label11_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.SteelBlue;
            this.panel5.Controls.Add(this.label16);
            this.panel5.Controls.Add(this.label17);
            this.panel5.Controls.Add(this.label18);
            this.panel5.Font = new System.Drawing.Font("Sitka Text", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel5.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.panel5.Location = new System.Drawing.Point(496, 299);
            this.panel5.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(555, 48);
            this.panel5.TabIndex = 11;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(51, 15);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(97, 20);
            this.label16.TabIndex = 0;
            this.label16.Text = "Curah Hujan";
            this.label16.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(211, 16);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(117, 20);
            this.label17.TabIndex = 4;
            this.label17.Text = "Solar Radiation";
            this.label17.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(388, 16);
            this.label18.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(94, 20);
            this.label18.TabIndex = 7;
            this.label18.Text = "Kelembaban";
            this.label18.TextAlign = System.Drawing.ContentAlignment.BottomRight;
            // 
            // port1
            // 
            this.port1.PortName = "COM5";
            // 
            // weatherWork
            // 
            this.weatherWork.DoWork += new System.ComponentModel.DoWorkEventHandler(this.weatherWorker_DoWork);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Interval = 60000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // lblValCurahHujan
            // 
            this.lblValCurahHujan.AutoSize = true;
            this.lblValCurahHujan.Font = new System.Drawing.Font("Sitka Text", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValCurahHujan.Location = new System.Drawing.Point(87, 182);
            this.lblValCurahHujan.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblValCurahHujan.Name = "lblValCurahHujan";
            this.lblValCurahHujan.Size = new System.Drawing.Size(24, 35);
            this.lblValCurahHujan.TabIndex = 18;
            this.lblValCurahHujan.Text = "-";
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(1067, 554);
            this.ControlBox = false;
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.btnData);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.btnCalibration);
            this.Controls.Add(this.lblInternet);
            this.Controls.Add(this.lblServer);
            this.Controls.Add(this.pctServer);
            this.Controls.Add(this.pctGlobe);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.lblDate);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.ImgLogo);
            this.Controls.Add(this.lblLogo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmMain";
            this.Text = "CAMS GUPIT";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pctServer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pctGlobe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ImgLogo)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLogo;
        private System.Windows.Forms.PictureBox ImgLogo;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Label lblDate;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblJenis;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label lblH2s;
        private System.Windows.Forms.Label lblValH2s;
        private System.Windows.Forms.Label lblValCs2;
        private System.Windows.Forms.Label lblCs2;
        private System.Windows.Forms.Button btnSatuan;
        private System.Windows.Forms.PictureBox pctGlobe;
        private System.Windows.Forms.PictureBox pctServer;
        private System.Windows.Forms.Label lblServer;
        private System.Windows.Forms.Label lblInternet;
        private System.Windows.Forms.Button btnCalibration;
        private System.Windows.Forms.Button btnData;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label lblValSpeed;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lblDirections;
        private System.Windows.Forms.Label lblValDirection;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblValTemperature;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label lblValPressure;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label lblKelembaban;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label lblValSolarRadiation;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cmbCs2;
        private System.Windows.Forms.ComboBox cmbH2s;
        public System.IO.Ports.SerialPort port1;
        private System.ComponentModel.BackgroundWorker weatherWork;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label lblValCurahHujan;
    }
}

