﻿// Decompiled with JetBrains decompiler
// Type: TrusurAQMCilegon2019.Functions.VoltageToValue
// Assembly: TrusurAQMCilegon2019, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4B8B87E8-4F91-4F01-A4B6-8776C395B724
// Assembly location: E:\trusur_juara\TrusurAQMCilegon2019\TrusurAQMCilegon2019.exe

using System;

namespace Aqms.Functions
{
    public class VoltageToValue
    {
        public static double getPM10(double voltage, double aPM10, double bPM10, int precision)
        {
            return Math.Round(200.392 * aPM10 * voltage - (0.955 + bPM10), precision);
        }

        public static double getPM25(double voltage, double aPM25, double bPM25, int precision)
        {
            return Math.Round(49.645 * aPM25 * voltage - (0.024 + bPM25), precision);
        }

        //public static double getH2s(double voltage, double aH2s, double bH2s, int precision)
        //{
        //    return Math.Round(49.645 * aH2s * voltage - (0.024 + bH2s), precision); 
        //}


        public static double getH2s(double voltage, double gainH2s, double offsetH2s, int precision)
        {
            //double valh2s = Math.Round((voltage * 3.2 * gainH2s) + offsetH2s, precision);
            double valh2s = Math.Round(3.2 * ((8.14664 + gainH2s) * voltage - (0.366599 + offsetH2s)), precision);
            return valh2s;
        }
        public static double getH2sCons(double voltage, double conH2s, int precision)
        {
            //double valh2s = Math.Round((voltage * 3.2 * gainH2s) + offsetH2s, precision);
            double valh2sCons = Math.Round(conH2s / 3.2 + 0.366599 - (8.14644 * voltage), precision);
            return valh2sCons;
        }
        public static double getCS2(double voltage, double gainCs2, double offsetCs2, int precision)
        {
            double valCS2 = Math.Round(1.2 * ((24.4399 + gainCs2) * voltage - (1.099 + offsetCs2)), precision);
            return valCS2;
        }





        public static double getSO2(double voltage, double gainSO2, double offsetbSO2, int precision)
        {
            double num = Math.Round((125.0 * voltage - 5.0) * gainSO2 + offsetbSO2, precision);
            if (num < 0.0)
                num = 0.0;
            return num;
        }

        public static double getCO(double voltage, double gainCO, double offsetCO, int precision)
        {
            double num = Math.Round((1250.0 * voltage - 50.0) * gainCO + offsetCO, precision);
            if (num < 0.0)
                num = 0.0;
            return num;
        }

        public static double getO3(double voltage, double aO3, double bO3, int precision)
        {
            double num = Math.Round((625.0 * voltage - 25.0) * aO3 + bO3, precision);
            if (num < 0.0)
                num = 0.0;
            return num;
        }

        public static double getNO2(double voltage, double aNO2, double bNO2, int precision)
        {
            double num = Math.Round((125.0 * voltage - 5.0) * aNO2 + bNO2, precision);
            if (num < 0.0)
                num = 0.0;
            return num;
        }

        public static double getHC(double voltage, double aHC, double bHC, int precision)
        {
            double num = Math.Round((364002231.0 * Math.Pow(voltage, 4.0) - 108931228.4 * Math.Pow(voltage, 3.0) + 11924488.64 * Math.Pow(voltage, 2.0) - 574919.2456 * voltage + 10778.05204) * aHC + bHC, precision);
            if (num < 0.0)
                num = 0.0;
            return num;
        }

        public static double getPPMtoPPB(double val)
        {
            return val * 1000.0;
        }
        public static double ConvertH2SppbToUGM(double val, int precision)
        {
            return Math.Round(val * 0.670, precision);
        }
        public static double ConvertCS2ppbToUGM(double val, int precision)
        {
            return Math.Round(val * 0.32, precision);
        }
        public static double convertSO2ppbToUGM(double val, int precision)
        {
            return Math.Round(val * 64.066 / 24.45, precision);
        }

        public static double convertCOppbToUGM(double val, int precision)
        {
            return Math.Round(val * 28.01 / 24.45, precision);
        }

        public static double convertO3ppbToUGM(double val, int precision)
        {
            return Math.Round(val * 48.0 / 24.45, precision);
        }

        public static double convertNO2ppbToUGM(double val, int precision)
        {
            return Math.Round(val * 46.0055 / 24.45, precision);
        }
    }
}
