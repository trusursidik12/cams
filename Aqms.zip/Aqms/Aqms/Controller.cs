﻿// Decompiled with JetBrains decompiler
// Type: TrusurAQMCilegon2019.Controller
// Assembly: TrusurAQMCilegon2019, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4B8B87E8-4F91-4F01-A4B6-8776C395B724
// Assembly location: E:\trusur_juara\TrusurAQMCilegon2019\TrusurAQMCilegon2019.exe

using System;
using System.Diagnostics;
using System.IO.Ports;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aqms
{
    public class Controller
    {
        private static readonly DateTime Jan1st1970 = new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc);
        private int _timeOut = 3000;
        private string[] _endResponses = new string[2]
        {
      "\r\n",
      "\n"
        };
        private SerialPort controller;
        private FrmMain frmMain;
        public Timer timer;
        public const int CH1 = 1;
        public const int CH2 = 2;
        public const int CH3 = 3;
        public const int CH4 = 4;
        public const int HIGH = 1;
        public const int LOW = 0;

        public Controller(FrmMain frmMain)
        {
            this.frmMain = frmMain;
            Task.Factory.StartNew((Action)(() => this.connect()));
            this.timer = new Timer();
            this.timer.Interval = 10000;
            this.timer.Enabled = true;
            this.timer.Tick += (EventHandler)((aSender, eArgs) => Task.Factory.StartNew((Action)(() => this.connect())));
        }

        public void connect()
        {

                //this.controller = new SerialPort(this.frmMain.konfigurasi.Controller, this.frmMain.konfigurasi.ControllerBaud, Parity.None, 8, StopBits.One);
                this.controller = new SerialPort("COM4", 9600, Parity.None, 8, StopBits.One);
                this.controller.NewLine = "\n";
                this.controller.ReadTimeout = 3000;
                this.controller.WriteTimeout = 3000;
                try
                {
                    this.controller.Open();
                    this.SetRelay(8, 1);
                }
                catch (Exception ex)
                {
                }
        }

        public bool isOpen()
        {
            if (this.controller != null)
                return this.controller.IsOpen;
            return false;
        }

        public static long CurrentTimeMillis()
        {
            return (long)(DateTime.UtcNow - Controller.Jan1st1970).TotalMilliseconds;
        }

        public bool SendText(string text)
        {
            try
            {
                if (!this.controller.IsOpen)
                    return false;
                this.controller.WriteLine("S|" + text);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public bool SetRelay(int relay, int value)
        {
            try
            {
                //if (!this.controller.IsOpen)
                //    //MessageBox.Show("Error Message", "Tidak Konek", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                //   return false;
                    string str = "Y";
                //if (value == 1)
                    MessageBox.Show(" Message", "Konek", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                str = "Y";
                this.controller.WriteLine(str + (object)relay);
                //this.controller.Write(str);
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public int IsRelayON(int relay)
        {
            try
            {
                if (!this.controller.IsOpen)
                    return -1;
                string str = "";
                this.controller.DiscardInBuffer();
                this.controller.DiscardOutBuffer();
                this.controller.WriteLine("N" + (object)relay);
                Debug.WriteLine("RESPONSE: " + str);
                return Convert.ToInt32(str);
            }
            catch (Exception ex)
            {
                return -1;
            }
        }
    }
}
