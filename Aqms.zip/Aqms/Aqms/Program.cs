﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aqms
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            using (Mutex mutex = new Mutex(false, "TrusurAQM"))
            {
                if (!mutex.WaitOne(0, false))
                {
                    int num = (int)MessageBox.Show("Instance already running", "Error", MessageBoxButtons.OK, MessageBoxIcon.Hand);
                }
                else
                {
                    Application.EnableVisualStyles();
                    Application.SetCompatibleTextRenderingDefault(false);
                    Application.Run((Form)new FrmMain());
                }
            }
        }
    }
}
