﻿// Decompiled with JetBrains decompiler
// Type: TrusurAQMCilegon2019.DataClass.WeatherLoopData
// Assembly: TrusurAQMCilegon2019, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4B8B87E8-4F91-4F01-A4B6-8776C395B724
// Assembly location: E:\trusur_juara\TrusurAQMCilegon2019\TrusurAQMCilegon2019.exe

using System;
using System.Diagnostics;
using System.Text;

namespace Aqms.DataClass
{
    public class WeatherLoopData
    {
        private int barTrend = 0;
        private int currWindSpeed = 0;
        private int avgWindSpeed = 0;
        private int insideHumidity = 0;
        private int outsideHumidity = 0;
        private int windDirection = 0;
        private float barometer = 0.0f;
        private float insideTemp = 0.0f;
        private float outsideTemp = 0.0f;
        private float dayRain = 0.0f;
        private float rainIntensity = 0.0f;
        private float solar = 0.0f;
        private DateTime sunRise = DateTime.Now;
        private DateTime sunSet = DateTime.Now;

        public int BarometricTrend
        {
            get
            {
                return this.barTrend;
            }
        }

        public int CurrentWindSpeed
        {
            get
            {
                return this.currWindSpeed;
            }
        }

        public int AvgWindSpeed
        {
            get
            {
                return this.avgWindSpeed;
            }
        }

        public int InsideHumidity
        {
            get
            {
                return this.insideHumidity;
            }
        }

        public int OutsideHumidity
        {
            get
            {
                return this.outsideHumidity;
            }
        }

        public float Barometer
        {
            get
            {
                return this.barometer;
            }
        }

        public float InsideTemperature
        {
            get
            {
                return this.insideTemp;
            }
        }

        public float OutsideTemperature
        {
            get
            {
                return this.outsideTemp;
            }
        }

        public float DailyRain
        {
            get
            {
                return this.dayRain;
            }
        }

        public float SolarRadiation
        {
            get
            {
                return this.solar;
            }
        }

        public int WindDirection
        {
            get
            {
                return this.windDirection;
            }
        }

        public DateTime SunRise
        {
            get
            {
                return this.sunRise;
            }
        }

        public DateTime SunSet
        {
            get
            {
                return this.sunSet;
            }
        }

        public bool Load(byte[] loopByteArray)
        {
            try
            {
                this.barTrend = Convert.ToInt32((sbyte)loopByteArray[3]);
                this.barometer = (float)BitConverter.ToInt16(loopByteArray, 7) / 1000f;
                this.insideTemp = (float)BitConverter.ToInt16(loopByteArray, 9) / 10f;
                this.insideHumidity = Convert.ToInt32(loopByteArray[11]);
                this.outsideTemp = (float)BitConverter.ToInt16(loopByteArray, 12) / 10f;
                this.outsideHumidity = Convert.ToInt32(loopByteArray[33]);
                this.windDirection = (int)BitConverter.ToInt16(loopByteArray, 16);
                this.currWindSpeed = Convert.ToInt32(loopByteArray[14]);
                this.avgWindSpeed = Convert.ToInt32(loopByteArray[15]);
                this.dayRain = (float)BitConverter.ToInt16(loopByteArray, 50) / 100f;
                this.solar = (float)Convert.ToInt32(loopByteArray[44]);
                this.rainIntensity = (float)(Convert.ToInt32(loopByteArray[41]) / 100) * 25.4f;
                DateTime now = DateTime.Now;
                short int16 = BitConverter.ToInt16(loopByteArray, 91);
                string str1 = int16.ToString();
                int int32_1 = Convert.ToInt32(str1.Substring(0, str1.Length - 2));
                int int32_2 = Convert.ToInt32(str1.Substring(str1.Length - 2, 2));
                this.sunRise = new DateTime(now.Year, now.Month, now.Day, int32_1, int32_2, 0);
                int16 = BitConverter.ToInt16(loopByteArray, 93);
                string str2 = int16.ToString();
                int int32_3 = Convert.ToInt32(str2.Substring(0, str2.Length - 2));
                int int32_4 = Convert.ToInt32(str2.Substring(str2.Length - 2, 2));
                this.sunSet = new DateTime(now.Year, now.Month, now.Day, int32_3, int32_4, 0);
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine("WS Load: " + ex.Message);
                return false;
            }
        }

        public string DebugString()
        {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append("Barometer: " + this.barometer.ToString("f2") + "in. " + this.BarTrendText() + Environment.NewLine);
            stringBuilder.Append("Inside Temp: " + this.insideTemp.ToString() + Environment.NewLine);
            stringBuilder.Append("Inside Humidity: " + this.insideHumidity.ToString() + "%" + Environment.NewLine);
            stringBuilder.Append("Outside Temp: " + this.outsideTemp.ToString() + Environment.NewLine);
            stringBuilder.Append("Outside Humidity: " + this.outsideHumidity.ToString() + "%" + Environment.NewLine);
            stringBuilder.Append("Wind Direction: " + this.WindDirectionText() + " @ " + this.windDirection.ToString() + " degrees" + Environment.NewLine);
            stringBuilder.Append("Current Wind Speed: " + this.currWindSpeed.ToString() + "MPH" + Environment.NewLine);
            stringBuilder.Append("10 Minute Average Wind Speed: " + this.avgWindSpeed.ToString() + "MPH" + Environment.NewLine);
            stringBuilder.Append("Daily Rain: " + this.dayRain.ToString() + "in" + Environment.NewLine);
            stringBuilder.Append("Sunrise: " + this.sunRise.ToString("t") + Environment.NewLine);
            stringBuilder.Append("Sunset: " + this.sunSet.ToString("t") + Environment.NewLine);
            return stringBuilder.ToString();
        }

        public WeatherData getData()
        {
            WeatherData weatherData = new WeatherData();
            weatherData.pressure = Math.Round((double)this.barometer * 33.8637526, 2);
            weatherData.temp = Math.Round(((double)this.outsideTemp - 32.0) * 5.0 / 9.0, 2);
            weatherData.humidity = (double)this.outsideHumidity;
            weatherData.wd = (double)this.windDirection;
            if (weatherData.wd > 360.0)
                weatherData.wd = -1.0;
            weatherData.ws = Math.Round((double)this.currWindSpeed * 1.609344, 2);
            weatherData.sr = (double)this.solar;
            weatherData.rain_intensity = (double)this.rainIntensity;
            weatherData.day_rain = Math.Round((double)this.dayRain * 25.4, 2);
            return weatherData;
        }

        public string WindDirectionText()
        {
            return this.windDirection < 337 && this.windDirection > 23 ? (this.windDirection <= 292 ? (this.windDirection < 247 ? (this.windDirection <= 203 ? (this.windDirection < 157 ? (this.windDirection <= 113 ? (this.windDirection < 67 ? (this.windDirection <= 23 ? "Undetermined" : "NE") : "E") : "SE") : "S") : "SW") : "W") : "NW") : "N";
        }

        public string BarTrendText()
        {
            switch (this.barTrend)
            {
                case -60:
                    return "Falling Rapidly";
                case -20:
                    return "Falling Slowly";
                case 0:
                    return "Steady";
                case 20:
                    return "Rising Slowly";
                case 60:
                    return "Rising Rapidly";
                default:
                    return "No Barometric Trend Available";
            }
        }
    }
}
