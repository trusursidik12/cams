﻿// Decompiled with JetBrains decompiler
// Type: TrusurAQMCilegon2019.DataClass.Konfigurasi
// Assembly: TrusurAQMCilegon2019, Version=1.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: 4B8B87E8-4F91-4F01-A4B6-8776C395B724
// Assembly location: E:\trusur_juara\TrusurAQMCilegon2019\TrusurAQMCilegon2019.exe

using MySql.Data.MySqlClient;
using System;
using System.ComponentModel;
using System.Diagnostics;

namespace Aqms
{
    [DefaultProperty("StasiunID")]
    public class Konfigurasi
    {
        public bool loaded = false;
        public bool enablePM10 = false;
        public bool enablePM25 = false;
        public bool enableSO2 = false;
        public bool enableCO = false;
        public bool enableO3 = false;
        public bool enableNO2 = false;
        public bool enableHC = false;
        public bool enableWS = false;
        public bool enableWD = false;
        public bool enableTemperature = false;
        public bool enableHumidity = false;
        public bool enablePressure = false;
        public bool enableSR = false;
        public bool enableVOC = false;
        public bool enableNH3 = false;
        public bool enableRainIntensity = false;
        public bool enableNO = false;
        public string sta_nama;
        public string sta_id;
        public string sta_alamat;
        public string sta_kota;
        public string sta_prov;
        public double sta_lat;
        public double sta_lon;
        public string com_ws;
        public string com_modem;
        public int baud_ws;
        public int baud_modem;
        public string data_server;
        public string server_sim_number;
        public string com_apc;
        public string alert_sim_number;
        public string power_failure_message;
        public string power_online_message;
        public int baud_apc;
        public string com_pm10;
        public string com_pm25;
        public int baud_pm10;
        public int baud_pm25;
        public string controller;
        public int controller_baud;
        public int pump_interval;
        public int pump_state;
        public DateTime pump_last;

        public Konfigurasi()
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection("host=127.0.0.1;port=3306;user id=root;password=root;database=trusur_aqm;"))
                {
                    mySqlConnection.Open();
                    using (MySqlCommand command = mySqlConnection.CreateCommand())
                    {
                        command.CommandText = "SELECT `data`,`content` FROM aqm_configuration";
                        using (MySqlDataReader mySqlDataReader = command.ExecuteReader())
                        {
                            while (mySqlDataReader.Read())
                            {
                                string str = mySqlDataReader.GetString("data");
                                string s = mySqlDataReader.GetString("content");
                                if (str == nameof(sta_nama))
                                    this.sta_nama = s;
                                if (str == nameof(sta_id))
                                    this.sta_id = s;
                                if (str == nameof(sta_alamat))
                                    this.sta_alamat = s;
                                if (str == nameof(sta_kota))
                                    this.sta_kota = s;
                                if (str == nameof(sta_prov))
                                    this.sta_prov = s;
                                if (str == nameof(sta_lat))
                                    this.sta_lat = Convert.ToDouble(s);
                                if (str == nameof(sta_lon))
                                    this.sta_lon = Convert.ToDouble(s);
                                if (str == nameof(com_ws))
                                    this.com_ws = s;
                                if (str == nameof(com_modem))
                                    this.com_modem = s;
                                if (str == nameof(baud_ws))
                                    this.baud_ws = Convert.ToInt32(s);
                                if (str == nameof(baud_modem))
                                    this.baud_modem = Convert.ToInt32(s);
                                if (str == nameof(data_server))
                                    this.data_server = s;
                                if (str == nameof(server_sim_number))
                                    this.server_sim_number = s;
                                if (str == nameof(com_apc))
                                    this.com_apc = s;
                                if (str == nameof(alert_sim_number))
                                    this.alert_sim_number = s;
                                if (str == nameof(power_failure_message))
                                    this.power_failure_message = s;
                                if (str == nameof(power_online_message))
                                    this.power_online_message = s;
                                if (str == nameof(baud_apc))
                                    this.baud_apc = Convert.ToInt32(s);
                                if (str == nameof(com_pm10))
                                    this.com_pm10 = s;
                                if (str == nameof(com_pm25))
                                    this.com_pm25 = s;
                                if (str == nameof(baud_pm10))
                                    this.baud_pm10 = Convert.ToInt32(s);
                                if (str == nameof(baud_pm25))
                                    this.baud_pm25 = Convert.ToInt32(s);
                                if (str == "e_pm10")
                                    this.enablePM10 = !(s == "0");
                                if (str == "e_pm25")
                                    this.enablePM25 = !(s == "0");
                                if (str == "e_so2")
                                    this.enableSO2 = !(s == "0");
                                if (str == "e_co")
                                    this.enableCO = !(s == "0");
                                if (str == "e_o3")
                                    this.enableO3 = !(s == "0");
                                if (str == "e_no2")
                                    this.enableNO2 = !(s == "0");
                                if (str == "e_hc")
                                    this.enableHC = !(s == "0");
                                if (str == "e_ws")
                                    this.enableWS = !(s == "0");
                                if (str == "e_wd")
                                    this.enableWD = !(s == "0");
                                if (str == "e_humidity")
                                    this.enableHumidity = !(s == "0");
                                if (str == "e_temperature")
                                    this.enableTemperature = !(s == "0");
                                if (str == "e_pressure")
                                    this.enablePressure = !(s == "0");
                                if (str == "e_sr")
                                    this.enableSR = !(s == "0");
                                if (str == "e_voc")
                                    this.enableVOC = !(s == "0");
                                if (str == "e_nh3")
                                    this.enableNH3 = !(s == "0");
                                if (str == "e_rain_intensity")
                                    this.enableRainIntensity = !(s == "0");
                                if (str == "e_no")
                                    this.enableNO = !(s == "0");
                                if (str == nameof(controller))
                                    this.controller = s;
                                if (str == nameof(controller_baud))
                                    this.controller_baud = Convert.ToInt32(s);
                                if (str == nameof(pump_interval))
                                    this.pump_interval = Convert.ToInt32(s);
                                if (str == nameof(pump_state))
                                    this.pump_state = Convert.ToInt32(s);
                                if (str == nameof(pump_last))
                                    this.pump_last = DateTime.Parse(s);
                            }
                            this.loaded = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error DB==========================================: " + ex.Message);
            }
        }

        [Category("Data Stasiun")]
        [Description("Nama stasiun akan tampil di tampilan depan")]
        [DisplayName("Nama Stasiun")]
        public string StasiunNama
        {
            get
            {
                return this.sta_nama;
            }
            set
            {
                this.sta_nama = value;
            }
        }

        [Category("Data Stasiun")]
        [Description("ID Stasiun yang dikirim bersama data")]
        [DisplayName("ID Stasiun")]
        public string StasiunID
        {
            get
            {
                return this.sta_id;
            }
            set
            {
                this.sta_id = value;
            }
        }

        [Category("Data Stasiun")]
        [Description("Alamat pemasangan stasiun")]
        [DisplayName("Alamat Stasiun")]
        public string StasiunAlamat
        {
            get
            {
                return this.sta_alamat;
            }
            set
            {
                this.sta_alamat = value;
            }
        }

        [Category("Data Stasiun")]
        [Description("Kota tempat pemasangan stasiun")]
        [DisplayName("Kota")]
        public string StasiunKota
        {
            get
            {
                return this.sta_kota;
            }
            set
            {
                this.sta_kota = value;
            }
        }

        [Category("Data Stasiun")]
        [Description("Provinsi tempat pemasangan stasiun")]
        [DisplayName("Provinsi")]
        public string StasiunProvinsi
        {
            get
            {
                return this.sta_prov;
            }
            set
            {
                this.sta_prov = value;
            }
        }

        [Category("Data Stasiun")]
        [Description("Latitude lokasi stasiun")]
        [TypeConverter(typeof(double))]
        [DisplayName("Latitude")]
        public double StasiunLatitude
        {
            get
            {
                return this.sta_lat;
            }
            set
            {
                this.sta_lat = value;
            }
        }

        [Category("Data Stasiun")]
        [Description("Longitude lokasi stasiun")]
        [TypeConverter(typeof(double))]
        [DisplayName("Longitude")]
        public double StasiunLongitude
        {
            get
            {
                return this.sta_lon;
            }
            set
            {
                this.sta_lon = value;
            }
        }

        [Category("Weather Station dan Modem")]
        [Description("Nomor COM Port pemasangan weather station di PC")]
        [DisplayName("COM Port Weather Station")]
        public string ComWS
        {
            get
            {
                return this.com_ws;
            }
            set
            {
                this.com_ws = value;
            }
        }

        [Category("Weather Station dan Modem")]
        [Description("Nomor COM Port pemasangan modem di PC")]
        [DisplayName("COM Port Modem")]
        public string ComModem
        {
            get
            {
                return this.com_modem;
            }
            set
            {
                this.com_modem = value;
            }
        }

        [Category("Weather Station dan Modem")]
        [Description("Nilai baud rate weather station")]
        [TypeConverter(typeof(int))]
        [DisplayName("Baud Rate Weather Station")]
        public int BaudWS
        {
            get
            {
                return this.baud_ws;
            }
            set
            {
                this.baud_ws = value;
            }
        }

        [Category("Weather Station dan Modem")]
        [Description("Nilai baud rate modem")]
        [TypeConverter(typeof(int))]
        [DisplayName("Baud Rate Modem")]
        public int BaudModem
        {
            get
            {
                return this.baud_modem;
            }
            set
            {
                this.baud_modem = value;
            }
        }

        [Category("Server")]
        [Description("IP atau Domain server data")]
        [DisplayName("IP Server")]
        public string DataServer
        {
            get
            {
                return this.data_server;
            }
            set
            {
                this.data_server = value;
            }
        }

        [Category("Server")]
        [Description("Nomor SIM Server untuk pengiriman melalui SMS")]
        [DisplayName("Nomor GSM Server")]
        public string NomorSIMServer
        {
            get
            {
                return this.server_sim_number;
            }
            set
            {
                this.server_sim_number = value;
            }
        }

        [Category("Data APC UPS")]
        [Description("COM Port dari APC")]
        [DisplayName("COM Port APC")]
        public string ComApc
        {
            get
            {
                return this.com_apc;
            }
            set
            {
                this.com_apc = value;
            }
        }

        [Category("Data APC UPS")]
        [Description("Nomor GSM yang dituju jika terjadi mati lampu")]
        [DisplayName("Nomor GSM Alert")]
        public string AlertSIMNumber
        {
            get
            {
                return this.alert_sim_number;
            }
            set
            {
                this.alert_sim_number = value;
            }
        }

        [Category("Data APC UPS")]
        [Description("Pesan jika mati lampu \n {0}: Nama Stasiun \n {1}: Waktu \n {2}Baterai")]
        [DisplayName("Pesan Listrik Mati")]
        public string PowerFailureMessage
        {
            get
            {
                return this.power_failure_message;
            }
            set
            {
                this.power_failure_message = value;
            }
        }

        [Category("Data APC UPS")]
        [Description("Pesan jika lampu menyala kembali \n {0}: Nama Stasiun \n {1}: Waktu")]
        [DisplayName("Pesan Listrik Menyala")]
        public string PowerOnlineMessage
        {
            get
            {
                return this.power_online_message;
            }
            set
            {
                this.power_online_message = value;
            }
        }

        [Category("Data APC UPS")]
        [Description("Nilai baud rate APC")]
        [TypeConverter(typeof(int))]
        [DisplayName("Baud Rate APC")]
        public int BaudApc
        {
            get
            {
                return this.baud_apc;
            }
            set
            {
                this.baud_apc = value;
            }
        }

        [Category("PM10 dan PM2.5")]
        [Description("Nomor COM Port pemasangan PM10")]
        [DisplayName("COM Port PM10")]
        public string ComPM10
        {
            get
            {
                return this.com_pm10;
            }
            set
            {
                this.com_pm10 = value;
            }
        }

        [Category("PM10 dan PM2.5")]
        [Description("Nomor COM Port pemasangan PM2.5")]
        [DisplayName("COM Port PM2.5")]
        public string ComPM25
        {
            get
            {
                return this.com_pm25;
            }
            set
            {
                this.com_pm25 = value;
            }
        }

        [Category("PM10 dan PM2.5")]
        [Description("Nilai baud rate PM10")]
        [TypeConverter(typeof(int))]
        [DisplayName("Baud Rate PM10")]
        public int BaudPM10
        {
            get
            {
                return this.baud_pm10;
            }
            set
            {
                this.baud_pm10 = value;
            }
        }

        [Category("PM10 dan PM2.5")]
        [Description("Nilai baud rate PM2.5")]
        [TypeConverter(typeof(int))]
        [DisplayName("Baud Rate PM2.5")]
        public int BaudPM25
        {
            get
            {
                return this.baud_pm25;
            }
            set
            {
                this.baud_pm25 = value;
            }
        }

        [Category("Controller")]
        [Description("COM System Control")]
        [DisplayName("COM System Control")]
        public string Controller
        {
            get
            {
                return this.controller;
            }
            set
            {
                this.controller = value;
            }
        }

        [Category("Controller")]
        [Description("Baud Rate System Control")]
        [TypeConverter(typeof(int))]
        [DisplayName("Baud Rate System Control")]
        public int ControllerBaud
        {
            get
            {
                return this.controller_baud;
            }
            set
            {
                this.controller_baud = value;
            }
        }

        public string toString()
        {
            return "Nama Stasiun: " + this.sta_nama + "\nStasiun ID: " + this.sta_id + "\nStasiun Alamat: " + this.sta_alamat + "\nStasiun Kota: " + this.sta_kota + "\nStasiun Provinsi: " + this.sta_prov + "\nStasiun Lat: " + (object)this.sta_lat + "\nStasiun Lon: " + (object)this.sta_lon + "\nBaud WS: " + (object)this.baud_ws + "\nBaud Modem: " + (object)this.baud_modem + "\nCOM WS: " + this.com_ws + "\nCOM Modem: " + this.com_modem + "\nData Server: " + this.data_server + "\nSIM Server: " + this.server_sim_number;
        }

        public void SavePumpInterval(int jam, int menit)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection("host=127.0.0.1;port=3306;user id=root;password=root;database=trusur_aqm;"))
                {
                    mySqlConnection.Open();
                    this.pump_interval = jam * 60 + menit;
                    using (MySqlCommand command = mySqlConnection.CreateCommand())
                    {
                        command.CommandText = "UPDATE aqm_configuration SET content=@pump_interval WHERE data='pump_interval';";
                        command.Parameters.AddWithValue("@pump_interval", (object)this.pump_interval);
                        command.ExecuteNonQuery();
                    }
                    Debug.WriteLine("PUMP_STATE: " + (object)this.pump_state);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error DB: " + ex.Message);
            }
        }

        public void ChangePumpState()
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection("host=127.0.0.1;port=3306;user id=root;password=root;database=trusur_aqm;"))
                {
                    mySqlConnection.Open();
                    this.pump_state = this.pump_state != 0 ? 0 : 1;
                    this.pump_last = DateTime.Now;
                    using (MySqlCommand command = mySqlConnection.CreateCommand())
                    {
                        command.CommandText = "UPDATE aqm_configuration SET content=@pump_state WHERE data='pump_state';UPDATE aqm_configuration SET content=@pump_last WHERE data='pump_last';";
                        command.Parameters.AddWithValue("@pump_last", (object)this.pump_last.ToString("yyyy-MM-dd HH:mm:ss"));
                        command.Parameters.AddWithValue("@pump_state", (object)this.pump_state);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error DB: " + ex.Message);
            }
        }

        public void ChangePumpState(int pump_state)
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection("host=127.0.0.1;port=3306;user id=root;password=root;database=trusur_aqm;"))
                {
                    mySqlConnection.Open();
                    this.pump_state = pump_state;
                    using (MySqlCommand command = mySqlConnection.CreateCommand())
                    {
                        command.CommandText = "UPDATE aqm_configuration SET content=@pump_state WHERE data='pump_state';";
                        command.Parameters.AddWithValue("@pump_state", (object)pump_state);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error DB: " + ex.Message);
            }
        }

        public void Simpan()
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection("host=127.0.0.1;port=3306;user id=root;password=root;database=trusur_aqm;"))
                {
                    mySqlConnection.Open();
                    using (MySqlCommand command = mySqlConnection.CreateCommand())
                    {
                        command.CommandText = "UPDATE aqm_configuration SET content=@sta_nama WHERE data='sta_nama';UPDATE aqm_configuration SET content=@sta_id WHERE data='sta_id';UPDATE aqm_configuration SET content=@sta_alamat WHERE data='sta_alamat';UPDATE aqm_configuration SET content=@sta_kota WHERE data='sta_kota';UPDATE aqm_configuration SET content=@sta_prov WHERE data='sta_prov';UPDATE aqm_configuration SET content=@sta_lat WHERE data='sta_lat';UPDATE aqm_configuration SET content=@sta_lon WHERE data='sta_lon';UPDATE aqm_configuration SET content=@com_ws WHERE data='com_ws';UPDATE aqm_configuration SET content=@com_modem WHERE data='com_modem';UPDATE aqm_configuration SET content=@baud_ws WHERE data='baud_ws';UPDATE aqm_configuration SET content=@baud_modem WHERE data='baud_modem';UPDATE aqm_configuration SET content=@data_server WHERE data='data_server';UPDATE aqm_configuration SET content=@com_apc WHERE data='com_apc';UPDATE aqm_configuration SET content=@alert_sim_number WHERE data='alert_sim_number';UPDATE aqm_configuration SET content=@power_failure_message WHERE data='power_failure_message';UPDATE aqm_configuration SET content=@power_online_message WHERE data='power_online_message';UPDATE aqm_configuration SET content=@baud_apc WHERE data='baud_apc';UPDATE aqm_configuration SET content=@com_pm10 WHERE data='com_pm10';UPDATE aqm_configuration SET content=@com_pm25 WHERE data='com_pm25';UPDATE aqm_configuration SET content=@baud_pm10 WHERE data='baud_pm10';UPDATE aqm_configuration SET content=@baud_pm25 WHERE data='baud_pm25';UPDATE aqm_configuration SET content=@controller WHERE data='controller';UPDATE aqm_configuration SET content=@controller_baud WHERE data='controller_baud';UPDATE aqm_configuration SET content=@server_sim_number WHERE data='server_sim_number';";
                        command.Parameters.AddWithValue("@sta_nama", (object)this.sta_nama);
                        command.Parameters.AddWithValue("@sta_id", (object)this.sta_id);
                        command.Parameters.AddWithValue("@sta_alamat", (object)this.sta_alamat);
                        command.Parameters.AddWithValue("@sta_kota", (object)this.sta_kota);
                        command.Parameters.AddWithValue("@sta_prov", (object)this.sta_prov);
                        command.Parameters.AddWithValue("@sta_lat", (object)this.sta_lat);
                        command.Parameters.AddWithValue("@sta_lon", (object)this.sta_lon);
                        command.Parameters.AddWithValue("@com_ws", (object)this.com_ws);
                        command.Parameters.AddWithValue("@com_modem", (object)this.com_modem);
                        command.Parameters.AddWithValue("@baud_ws", (object)this.baud_ws);
                        command.Parameters.AddWithValue("@baud_modem", (object)this.baud_modem);
                        command.Parameters.AddWithValue("@data_server", (object)this.data_server);
                        command.Parameters.AddWithValue("@server_sim_number", (object)this.server_sim_number);
                        command.Parameters.AddWithValue("@com_pm10", (object)this.com_pm10);
                        command.Parameters.AddWithValue("@com_pm25", (object)this.com_pm25);
                        command.Parameters.AddWithValue("@baud_pm10", (object)this.baud_pm10);
                        command.Parameters.AddWithValue("@baud_pm25", (object)this.baud_pm25);
                        command.Parameters.AddWithValue("@com_apc", (object)this.com_apc);
                        command.Parameters.AddWithValue("@alert_sim_number", (object)this.alert_sim_number);
                        command.Parameters.AddWithValue("@power_failure_message", (object)this.power_failure_message);
                        command.Parameters.AddWithValue("@power_online_message", (object)this.power_online_message);
                        command.Parameters.AddWithValue("@baud_apc", (object)this.baud_apc);
                        command.Parameters.AddWithValue("@controller", (object)this.controller);
                        command.Parameters.AddWithValue("@controller_baud", (object)this.controller_baud);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error DB: " + ex.Message);
            }
        }
    }
}
