﻿using System;
using System.Collections.Generic;
using Aqms.Functions;

namespace Aqms.DataClass
{
    public class GasData
    {
        private List<double> datas = new List<double>();
        private double voltage = 0.0;
        private double ppm = 0.0;
        private double ppb = 0.0;
        private double ugm = 0.0;
        public const int TYPE_SO2 = 0;
        public const int TYPE_CO = 1;
        public const int TYPE_O3 = 2;
        public const int TYPE_NO2 = 3;
        public const int TYPE_HC = 4;
        public const int TYPE_HC_RANDOM = 5;
        private FrmMain frmMain;

        public GasData(FrmMain frmMain)
        {
            this.frmMain = frmMain;
        }

        public void setValue(double voltage, int type)
        {
            switch (type)
            {
                case 0:
                    this.voltage = voltage;
                    this.ppm = VoltageToValue.getSO2(voltage, this.frmMain.calibrationFactor.GainSO2, this.frmMain.calibrationFactor.OffsetSO2, 3);
                    this.ppb = VoltageToValue.getPPMtoPPB(this.ppm);
                    this.ugm = VoltageToValue.convertSO2ppbToUGM(this.ppb, 0);
                    break;
                case 1:
                    this.voltage = voltage;
                    this.ppm = VoltageToValue.getCO(voltage, this.frmMain.calibrationFactor.GainCO, this.frmMain.calibrationFactor.OffsetCO, 3);
                    this.ppb = VoltageToValue.getPPMtoPPB(this.ppm);
                    this.ugm = VoltageToValue.convertCOppbToUGM(this.ppb, 0);
                    break;
                case 2:
                    this.voltage = voltage;
                    this.ppm = VoltageToValue.getO3(voltage, this.frmMain.calibrationFactor.GainO3, this.frmMain.calibrationFactor.OffsetO3, 3);
                    this.ppb = VoltageToValue.getPPMtoPPB(this.ppm);
                    this.ugm = VoltageToValue.convertO3ppbToUGM(this.ppb, 0);
                    break;
                case 3:
                    this.voltage = voltage;
                    this.ppm = VoltageToValue.getNO2(voltage, this.frmMain.calibrationFactor.GainNO2, this.frmMain.calibrationFactor.OffsetNO2, 3);
                    this.ppb = VoltageToValue.getPPMtoPPB(this.ppm);
                    this.ugm = VoltageToValue.convertNO2ppbToUGM(this.ppb, 0);
                    break;
                case 4:
                    this.voltage = voltage;
                    this.ppm = VoltageToValue.getHC(voltage, this.frmMain.calibrationFactor.GainHC, this.frmMain.calibrationFactor.OffsetHC, 3);
                    this.ppb = VoltageToValue.getPPMtoPPB(this.ppm);
                    this.ugm = VoltageToValue.convertNO2ppbToUGM(this.ppb, 0);
                    break;
                case 5:
                    this.voltage = voltage / 2.2;
                    this.ppm = voltage;
                    this.ppb = VoltageToValue.getPPMtoPPB(this.ppm);
                    this.ugm = Math.Round(this.ppm * 706.0, 0);
                    break;
                case 6:
                    this.voltage = voltage;
                    this.ppm = VoltageToValue.getH2s(voltage, this.frmMain.calibrationFactor.GainH2s, this.frmMain.calibrationFactor.OffsetH2s, 3);
                    this.ppb = VoltageToValue.getPPMtoPPB(this.ppm);
                    this.ugm = VoltageToValue.ConvertH2SppbToUGM(this.ppb, 0);
                    break;
                case 7:
                    this.voltage = voltage;
                    this.ppm = VoltageToValue.getCS2(voltage, this.frmMain.calibrationFactor.GainCS2, this.frmMain.calibrationFactor.OffsetCs2, 3);
                    this.ppb = VoltageToValue.getPPMtoPPB(this.ppm);
                    this.ugm = VoltageToValue.ConvertCS2ppbToUGM(this.ppb, 0);
                    break;
            }
        }

        public double getValue(int type)
        {
            switch (type)
            {
                case 0:
                    return this.ppm;
                case 1:
                    return this.ppb;
                case 2:
                    return this.ugm;
                case 3:
                    return this.voltage;
                default:
                    return this.ppm;
            }
        }

        public void addData()
        {
            this.datas.Add(this.ugm);
            if (this.datas.Count <= 60)
                return;
            double mode = Extensions.FindMode(this.datas);
            this.datas.Clear();
            this.datas.Add(mode);
        }

        public double GetData()
        {
            double mode = Extensions.FindMode(this.datas);
            if (this.datas.Count > 0)
                this.datas.Clear();
            return mode;
        }
    }
}
