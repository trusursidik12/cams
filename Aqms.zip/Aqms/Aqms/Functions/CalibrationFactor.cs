﻿using MySql.Data.MySqlClient;
using System;
using System.Diagnostics;


namespace Aqms.Functions
{
    public class CalibrationFactor
    {
        public double GainSO2 = 1.0;
        public double OffsetSO2 = 0.0;
        public double GainCO = 1.0;
        public double OffsetCO = 0.0;
        public double GainO3 = 1.0;
        public double OffsetO3 = 0.0;
        public double GainNO2 = 1.0;
        public double OffsetNO2 = 0.0;
        public double GainHC = 1.0;
        public double OffsetHC = 0.0;
        public double GainH2s = 0.0;
        public double OffsetH2s = 0.0;
        public double GainCS2 = 1.0;
        public double OffsetCs2 = 0.0;
        public bool loaded = false;

        public CalibrationFactor()
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection("host=127.0.0.1;port=3306;user id=root;password=root;database=trusur_aqm;"))
                {
                    mySqlConnection.Open();
                    using (MySqlCommand command = mySqlConnection.CreateCommand())
                    {
                        command.CommandText = "SELECT `faktor`,`nilai` FROM aqm_calibration_factor";
                        using (MySqlDataReader mySqlDataReader = command.ExecuteReader())
                        {
                            while (mySqlDataReader.Read())
                            {
                                string str = mySqlDataReader.GetString("faktor");
                                double num = mySqlDataReader.GetDouble("nilai");
                                if (str == "aso2")
                                    this.GainSO2 = num;
                                if (str == "aco")
                                    this.GainCO = num;
                                if (str == "ao3")
                                    this.GainO3 = num;
                                if (str == "ano2")
                                    this.GainNO2 = num;
                                if (str == "ahc")
                                    this.GainHC = num;
                                if (str == "ah2s")
                                    this.GainH2s = num;
                                if (str == "acs2")
                                    this.GainCS2 = num;
                                if (str == "bso2")
                                    this.OffsetSO2 = num;
                                if (str == "bco")
                                    this.OffsetCO = num;
                                if (str == "bo3")
                                    this.OffsetO3 = num;
                                if (str == "bno2")
                                    this.OffsetNO2 = num;
                                if (str == "bhc")
                                    this.OffsetHC = num;
                                if (str == "bh2s")
                                    this.OffsetH2s = num;
                                if (str == "bcs2")
                                    this.OffsetCs2 = num;
                            }
                            this.loaded = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error DB: " + ex.Message);
            }
        }

        public void simpan()
        {
            try
            {
                using (MySqlConnection mySqlConnection = new MySqlConnection("host=127.0.0.1;port=3306;user id=root;password=root;database=trusur_aqm;"))
                {
                    mySqlConnection.Open();
                    using (MySqlCommand command = mySqlConnection.CreateCommand())
                    {
                        command.CommandText = "UPDATE aqm_calibration_factor SET nilai=@aso2 WHERE faktor='aso2';UPDATE aqm_calibration_factor SET nilai=@aco WHERE faktor='aco';UPDATE aqm_calibration_factor SET nilai=@ao3 WHERE faktor='ao3';UPDATE aqm_calibration_factor SET nilai=@ano2 WHERE faktor='ano2';UPDATE aqm_calibration_factor SET nilai=@ahc WHERE faktor='ahc';UPDATE aqm_calibration_factor SET nilai=@ah2s WHERE faktor='ah2s';UPDATE aqm_calibration_factor SET nilai=@acs2 WHERE faktor='acs2';UPDATE aqm_calibration_factor SET nilai=@bso2 WHERE faktor='bso2';UPDATE aqm_calibration_factor SET nilai=@bco WHERE faktor='bco';UPDATE aqm_calibration_factor SET nilai=@bo3 WHERE faktor='bo3';UPDATE aqm_calibration_factor SET nilai=@bno2 WHERE faktor='bno2';UPDATE aqm_calibration_factor SET nilai=@bhc WHERE faktor='bhc';UPDATE aqm_calibration_factor SET nilai=@bh2s WHERE faktor='bh2s';UPDATE aqm_calibration_factor SET nilai=@bcs2 WHERE faktor='bcs2';";
                        command.Parameters.AddWithValue("@aso2", (object)this.GainSO2);
                        command.Parameters.AddWithValue("@aco", (object)this.GainCO);
                        command.Parameters.AddWithValue("@ao3", (object)this.GainO3);
                        command.Parameters.AddWithValue("@ano2", (object)this.GainNO2);
                        command.Parameters.AddWithValue("@ahc", (object)this.GainHC);
                        command.Parameters.AddWithValue("@ah2s", (object)this.GainH2s);
                        command.Parameters.AddWithValue("@acs2", (object)this.GainCS2);
                        command.Parameters.AddWithValue("@bso2", (object)this.OffsetSO2);
                        command.Parameters.AddWithValue("@bco", (object)this.OffsetCO);
                        command.Parameters.AddWithValue("@bo3", (object)this.OffsetO3);
                        command.Parameters.AddWithValue("@bno2", (object)this.OffsetNO2);
                        command.Parameters.AddWithValue("@bhc", (object)this.OffsetHC);
                        command.Parameters.AddWithValue("@bh2s", (object)this.OffsetH2s);
                        command.Parameters.AddWithValue("@bcs2", (object)this.OffsetCs2);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine("Error DB: " + ex.Message);
            }
        }
    }
}
