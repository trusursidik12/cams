﻿namespace Aqms
{
    partial class FrmCalibration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.btnCalibration = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.pnlZeroCal = new System.Windows.Forms.Panel();
            this.btnSelesai = new System.Windows.Forms.Button();
            this.tblCal = new System.Windows.Forms.ListView();
            this.clH2s = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clCs2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.btnCalCs2 = new System.Windows.Forms.Button();
            this.btnCalH2s = new System.Windows.Forms.Button();
            this.txtCalCs2 = new System.Windows.Forms.TextBox();
            this.txtCalH2s = new System.Windows.Forms.TextBox();
            this.cBCs2 = new System.Windows.Forms.CheckBox();
            this.cBH2s = new System.Windows.Forms.CheckBox();
            this.pnlSpanCal = new System.Windows.Forms.Panel();
            this.pnlPump = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblZero = new System.Windows.Forms.Label();
            this.ZeroCal = new System.Windows.Forms.Timer(this.components);
            this.port2 = new System.IO.Ports.SerialPort(this.components);
            this.btnPurging = new System.Windows.Forms.Button();
            this.btnOffPurging = new System.Windows.Forms.Button();
            this.pnlZeroCal.SuspendLayout();
            this.pnlSpanCal.SuspendLayout();
            this.pnlPump.SuspendLayout();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button1.Image = global::Aqms.Properties.Resources.calibration_mark__1_;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(12, 144);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(151, 42);
            this.button1.TabIndex = 4;
            this.button1.Text = "Span Cal";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.Button1_Click);
            // 
            // btnCalibration
            // 
            this.btnCalibration.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalibration.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnCalibration.Image = global::Aqms.Properties.Resources.calibration_mark__1_;
            this.btnCalibration.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCalibration.Location = new System.Drawing.Point(12, 88);
            this.btnCalibration.Name = "btnCalibration";
            this.btnCalibration.Size = new System.Drawing.Size(151, 42);
            this.btnCalibration.TabIndex = 3;
            this.btnCalibration.Text = "Zero Cal";
            this.btnCalibration.UseVisualStyleBackColor = true;
            this.btnCalibration.Click += new System.EventHandler(this.BtnCalibration_Click);
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button2.Image = global::Aqms.Properties.Resources.calibration_mark__1_;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(12, 197);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(151, 42);
            this.button2.TabIndex = 5;
            this.button2.Text = "Pump";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.Button2_Click);
            // 
            // pnlZeroCal
            // 
            this.pnlZeroCal.Controls.Add(this.btnSelesai);
            this.pnlZeroCal.Controls.Add(this.tblCal);
            this.pnlZeroCal.Controls.Add(this.btnCalCs2);
            this.pnlZeroCal.Controls.Add(this.btnCalH2s);
            this.pnlZeroCal.Controls.Add(this.txtCalCs2);
            this.pnlZeroCal.Controls.Add(this.txtCalH2s);
            this.pnlZeroCal.Controls.Add(this.cBCs2);
            this.pnlZeroCal.Controls.Add(this.cBH2s);
            this.pnlZeroCal.Controls.Add(this.pnlSpanCal);
            this.pnlZeroCal.Controls.Add(this.lblZero);
            this.pnlZeroCal.Location = new System.Drawing.Point(170, 21);
            this.pnlZeroCal.Name = "pnlZeroCal";
            this.pnlZeroCal.Size = new System.Drawing.Size(618, 417);
            this.pnlZeroCal.TabIndex = 6;
            this.pnlZeroCal.Visible = false;
            // 
            // btnSelesai
            // 
            this.btnSelesai.Location = new System.Drawing.Point(4, 83);
            this.btnSelesai.Name = "btnSelesai";
            this.btnSelesai.Size = new System.Drawing.Size(125, 23);
            this.btnSelesai.TabIndex = 9;
            this.btnSelesai.Text = "Selesai";
            this.btnSelesai.UseVisualStyleBackColor = true;
            this.btnSelesai.Visible = false;
            this.btnSelesai.Click += new System.EventHandler(this.BtnSelesai_Click_1);
            // 
            // tblCal
            // 
            this.tblCal.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clH2s,
            this.clCs2});
            this.tblCal.FullRowSelect = true;
            this.tblCal.HideSelection = false;
            this.tblCal.Location = new System.Drawing.Point(244, 20);
            this.tblCal.Name = "tblCal";
            this.tblCal.Size = new System.Drawing.Size(367, 389);
            this.tblCal.TabIndex = 8;
            this.tblCal.UseCompatibleStateImageBehavior = false;
            this.tblCal.View = System.Windows.Forms.View.Details;
            // 
            // clH2s
            // 
            this.clH2s.Text = "H2S";
            // 
            // clCs2
            // 
            this.clCs2.Text = "CS2";
            // 
            // btnCalCs2
            // 
            this.btnCalCs2.Location = new System.Drawing.Point(163, 49);
            this.btnCalCs2.Name = "btnCalCs2";
            this.btnCalCs2.Size = new System.Drawing.Size(75, 23);
            this.btnCalCs2.TabIndex = 7;
            this.btnCalCs2.Text = "Set Kalibrasi";
            this.btnCalCs2.UseVisualStyleBackColor = true;
            this.btnCalCs2.Visible = false;
            this.btnCalCs2.Click += new System.EventHandler(this.BtnCalCs2_Click);
            // 
            // btnCalH2s
            // 
            this.btnCalH2s.Location = new System.Drawing.Point(163, 22);
            this.btnCalH2s.Name = "btnCalH2s";
            this.btnCalH2s.Size = new System.Drawing.Size(75, 23);
            this.btnCalH2s.TabIndex = 6;
            this.btnCalH2s.Text = "Set Kalibrasi";
            this.btnCalH2s.UseVisualStyleBackColor = true;
            this.btnCalH2s.Visible = false;
            this.btnCalH2s.Click += new System.EventHandler(this.BtnCalH2s_Click);
            // 
            // txtCalCs2
            // 
            this.txtCalCs2.Location = new System.Drawing.Point(56, 50);
            this.txtCalCs2.Name = "txtCalCs2";
            this.txtCalCs2.Size = new System.Drawing.Size(100, 20);
            this.txtCalCs2.TabIndex = 5;
            this.txtCalCs2.Visible = false;
            this.txtCalCs2.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TxtCalCs2_KeyUp);
            // 
            // txtCalH2s
            // 
            this.txtCalH2s.Location = new System.Drawing.Point(56, 24);
            this.txtCalH2s.Name = "txtCalH2s";
            this.txtCalH2s.Size = new System.Drawing.Size(100, 20);
            this.txtCalH2s.TabIndex = 4;
            this.txtCalH2s.Visible = false;
            this.txtCalH2s.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TxtCalH2s_KeyUp);
            // 
            // cBCs2
            // 
            this.cBCs2.AutoSize = true;
            this.cBCs2.Location = new System.Drawing.Point(4, 53);
            this.cBCs2.Name = "cBCs2";
            this.cBCs2.Size = new System.Drawing.Size(44, 17);
            this.cBCs2.TabIndex = 3;
            this.cBCs2.Text = "Cs2";
            this.cBCs2.UseVisualStyleBackColor = true;
            this.cBCs2.Visible = false;
            this.cBCs2.CheckedChanged += new System.EventHandler(this.CBCs2_CheckedChanged);
            // 
            // cBH2s
            // 
            this.cBH2s.AutoSize = true;
            this.cBH2s.Location = new System.Drawing.Point(4, 27);
            this.cBH2s.Name = "cBH2s";
            this.cBH2s.Size = new System.Drawing.Size(45, 17);
            this.cBH2s.TabIndex = 2;
            this.cBH2s.Text = "H2s";
            this.cBH2s.UseVisualStyleBackColor = true;
            this.cBH2s.Visible = false;
            this.cBH2s.CheckedChanged += new System.EventHandler(this.CBH2s_CheckedChanged);
            // 
            // pnlSpanCal
            // 
            this.pnlSpanCal.Controls.Add(this.pnlPump);
            this.pnlSpanCal.Controls.Add(this.label1);
            this.pnlSpanCal.Location = new System.Drawing.Point(4, 4);
            this.pnlSpanCal.Name = "pnlSpanCal";
            this.pnlSpanCal.Size = new System.Drawing.Size(607, 410);
            this.pnlSpanCal.TabIndex = 1;
            this.pnlSpanCal.Visible = false;
            // 
            // pnlPump
            // 
            this.pnlPump.Controls.Add(this.label2);
            this.pnlPump.Location = new System.Drawing.Point(3, 3);
            this.pnlPump.Name = "pnlPump";
            this.pnlPump.Size = new System.Drawing.Size(605, 411);
            this.pnlPump.TabIndex = 1;
            this.pnlPump.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(297, 4);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Pump panel";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(294, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Span Cal Panel";
            // 
            // lblZero
            // 
            this.lblZero.AutoSize = true;
            this.lblZero.Location = new System.Drawing.Point(301, 4);
            this.lblZero.Name = "lblZero";
            this.lblZero.Size = new System.Drawing.Size(76, 13);
            this.lblZero.TabIndex = 0;
            this.lblZero.Text = "Panel Zero cal";
            // 
            // ZeroCal
            // 
            this.ZeroCal.Interval = 1000;
            this.ZeroCal.Tick += new System.EventHandler(this.ZeroCal_Tick);
            // 
            // port2
            // 
            this.port2.PortName = "COM5";
            // 
            // btnPurging
            // 
            this.btnPurging.BackColor = System.Drawing.Color.OliveDrab;
            this.btnPurging.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPurging.ForeColor = System.Drawing.Color.SeaShell;
            this.btnPurging.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPurging.Location = new System.Drawing.Point(12, 32);
            this.btnPurging.Name = "btnPurging";
            this.btnPurging.Size = new System.Drawing.Size(151, 42);
            this.btnPurging.TabIndex = 7;
            this.btnPurging.Text = "Set On Purging";
            this.btnPurging.UseVisualStyleBackColor = false;
            this.btnPurging.Click += new System.EventHandler(this.Button3_Click);
            // 
            // btnOffPurging
            // 
            this.btnOffPurging.BackColor = System.Drawing.Color.Maroon;
            this.btnOffPurging.Font = new System.Drawing.Font("Sitka Text", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnOffPurging.ForeColor = System.Drawing.Color.SeaShell;
            this.btnOffPurging.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOffPurging.Location = new System.Drawing.Point(12, 32);
            this.btnOffPurging.Name = "btnOffPurging";
            this.btnOffPurging.Size = new System.Drawing.Size(151, 42);
            this.btnOffPurging.TabIndex = 8;
            this.btnOffPurging.Text = "Set Off Purging";
            this.btnOffPurging.UseVisualStyleBackColor = false;
            this.btnOffPurging.Visible = false;
            this.btnOffPurging.Click += new System.EventHandler(this.BtnOffPurging_Click);
            // 
            // FrmCalibration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnOffPurging);
            this.Controls.Add(this.btnPurging);
            this.Controls.Add(this.pnlZeroCal);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.btnCalibration);
            this.Name = "FrmCalibration";
            this.Text = "FrmCalibration";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmCalibration_FormClosed);
            this.Load += new System.EventHandler(this.FrmCalibration_Load);
            this.pnlZeroCal.ResumeLayout(false);
            this.pnlZeroCal.PerformLayout();
            this.pnlSpanCal.ResumeLayout(false);
            this.pnlSpanCal.PerformLayout();
            this.pnlPump.ResumeLayout(false);
            this.pnlPump.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCalibration;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel pnlZeroCal;
        private System.Windows.Forms.Label lblZero;
        private System.Windows.Forms.Panel pnlSpanCal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel pnlPump;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.CheckBox cBCs2;
        private System.Windows.Forms.CheckBox cBH2s;
        private System.Windows.Forms.TextBox txtCalCs2;
        private System.Windows.Forms.TextBox txtCalH2s;
        private System.Windows.Forms.Button btnCalCs2;
        private System.Windows.Forms.Button btnCalH2s;
        private System.Windows.Forms.Timer ZeroCal;
        private System.Windows.Forms.ListView tblCal;
        private System.Windows.Forms.ColumnHeader clH2s;
        private System.Windows.Forms.ColumnHeader clCs2;
        private System.IO.Ports.SerialPort port2;
        private System.Windows.Forms.Button btnSelesai;
        private System.Windows.Forms.Button btnPurging;
        private System.Windows.Forms.Button btnOffPurging;
    }
}