﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO.Ports;
namespace Aqms
{
    public partial class FrmCalibration : Form
    {
        bool btnpurgings = false;
        SerialPort port;
        String[] ports;
        private double vth2s = 0;
        private double h2s = 0.0;
        private double cs2 = 0.0;
        private FrmMain frmMain;
        public FrmCalibration(FrmMain f)
        {
            InitializeComponent();
            this.frmMain = f;
            //getAvailablePortNames();
            port2.Open();
            port2.Write("g");

            //port2.Write("a");
            //port2.Write("b");
            //port2.Write("c");
            //port2.Write("d");
            //port2.Write("e");
            //port2.Write("f");

            btnpurgings = true;
            port2.DtrEnable = true;
            //this.frmMain.controller.SetRelay(7, 1);
            //this.frmMain.controller.SetRelay(8, 1);
            //this.frmMain.controller.SetRelay(9, 1);
        }
        private void FrmCalibration_FormClosed(object sender, FormClosedEventArgs e)
        {

            port2.Write("h");
            port2.Close();
        }
        private void connectToArduino()
        {
            
        }

        private void getAvailablePortNames()
        {
            ports = SerialPort.GetPortNames();
        }

        private void BtnCalibration_Click(object sender, EventArgs e)
        {
            if (btnOffPurging.Visible == true)
            {
                port2.Write("j");
                btnOffPurging.Visible = false;
                btnPurging.Visible = true;
            }
            pnlZeroCal.Visible = true;
            pnlPump.Visible = false;
            pnlSpanCal.Visible = false;
            tblCal.Visible = true;
            cBCs2.Visible = true;
            cBH2s.Visible = true;
            txtCalCs2.Visible = true;
            txtCalH2s.Visible = true;
            btnCalH2s.Visible = true;
            btnCalCs2.Visible = true;
            txtCalCs2.Enabled = false;
            btnCalCs2.Enabled = false;
            txtCalH2s.Enabled = false;
            btnCalH2s.Enabled = false;
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            //pnlZeroCal.Visible = false;
            //pnlPump.Visible = false;

            //port2.Write("j");
            if(btnOffPurging.Visible == true)
            {
                port2.Write("j");
                btnOffPurging.Visible = false;
                btnPurging.Visible = true;
            }
            pnlSpanCal.Visible = true;
            cBCs2.Visible = false;
            cBH2s.Visible = false;
            txtCalCs2.Visible = false;
            txtCalH2s.Visible = false;
            btnCalH2s.Visible = false;
            btnCalCs2.Visible = false;
            tblCal.Visible = false;
        }

        private void Button2_Click(object sender, EventArgs e)
        {
            //pnlZeroCal.Visible = false;
            if (btnOffPurging.Visible == true)
            {
                port2.Write("j");
                btnOffPurging.Visible = false;
                btnPurging.Visible = true;
            }
            //port2.Write("j");
            pnlPump.Visible = true;  
            cBCs2.Visible = false;
            cBH2s.Visible = false;
            txtCalCs2.Visible = false;
            txtCalH2s.Visible = false;
            btnCalH2s.Visible = false;
            btnCalCs2.Visible = false;
            tblCal.Visible = false;
            //pnlSpanCal.Visible = false;
        }

        private void CBH2s_CheckedChanged(object sender, EventArgs e)
        {
            btnSelesai.Visible = true;
            if (cBH2s.Checked == true)
            {
                ZeroCal.Start();
                port2.Write("k");
                txtCalH2s.Enabled = true;
                //txtCalH2s.Text = this.getH2S();
                btnCalH2s.Enabled = true;
            }

            if (cBH2s.Checked == false)
            {
                ZeroCal.Stop();
                btnSelesai.Visible = false;
                txtCalH2s.Enabled = false;
                btnCalH2s.Enabled = false;
            }
        }

        private void CBCs2_CheckedChanged(object sender, EventArgs e)
        {
            btnSelesai.Visible = true;
            if (cBCs2.Checked == true)
            {
                ZeroCal.Start();
                port2.Write("k");
                txtCalCs2.Enabled = true;
                btnCalCs2.Enabled = true;
            }

            if (cBCs2.Checked == false)
            {
                ZeroCal.Stop();
                btnSelesai.Visible = false;
                txtCalCs2.Enabled = false;
                btnCalCs2.Enabled = false;
            }
        }
       
        private void TxtCalH2s_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                txtCalH2s.Text = string.Format(System.Globalization.CultureInfo.GetCultureInfo("id-ID"), "{0:#,##0.000}", double.Parse(txtCalH2s.Text));
            }
            catch (Exception ex) { 

            }
            
        }
        private void TxtCalCs2_KeyUp(object sender, KeyEventArgs e)
        {
            try
            {
                txtCalCs2.Text = string.Format(System.Globalization.CultureInfo.GetCultureInfo("id-ID"), "{0:#,##0.000}", double.Parse(txtCalCs2.Text));
            }
            catch (Exception ex)
            {

            }
        }

        private void ZeroCal_Tick(object sender, EventArgs e)
        {
            if (this.h2s < this.frmMain.H2S_DATA.getValue(0))
                this.h2s = this.frmMain.H2S_DATA.getValue(0);
            if (this.cs2 < this.frmMain.Cs2_DATA.getValue(0))
                this.cs2 = this.frmMain.Cs2_DATA.getValue(0);
            if (cBH2s.Checked == true)
            {
                //txtCalH2s.Text = this.getH2S();
            }
            if (this.tblCal.Items.Count > 50)
            this.tblCal.Items.Clear();
            this.tblCal.Items.Add(new ListViewItem(this.getH2S())
            {
                SubItems = {
                    this.getCS2()
            }
            });
            this.tblCal.Items[this.tblCal.Items.Count - 1].EnsureVisible();


        }
        private string getH2S()
        {
            return this.cBH2s.Checked ? this.frmMain.H2S_DATA.getValue(0).ToString() : "";
        }

        private string getCS2()
        {
            return this.cBCs2.Checked ? this.frmMain.Cs2_DATA.getValue(0).ToString() : "";
        }

        private void TblCal_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void FrmCalibration_Load(object sender, EventArgs e)
        {
        }

        private void FrmCalibration_FormClosing(object sender, FormClosingEventArgs e)
        {
            MessageBox.Show("Closed");
        }

        private void BtnCalH2s_Click(object sender, EventArgs e)
        {
            this.frmMain.calibrationFactor.OffsetH2s = -this.h2s / 3.2 + 0.366599 - (8.14664 * this.vth2s);
            this.frmMain.calibrationFactor.simpan();
        }

        private void BtnCalCs2_Click(object sender, EventArgs e)
        {
            this.frmMain.calibrationFactor.OffsetCs2 = -this.cs2;
            this.frmMain.calibrationFactor.simpan();
        }

        private void BtnSelesai_Click(object sender, EventArgs e)
        {
            port2.Write("l");
            btnSelesai.Visible = false;
        }

        private void BtnSelesai_Click_1(object sender, EventArgs e)
        {
            port2.Write("l");
            btnSelesai.Visible = false;
        }

        private void Button3_Click(object sender, EventArgs e)
        {
            port2.Write("i");
            btnPurging.Visible = false;
            btnOffPurging.Visible = true;
        }

        private void BtnOffPurging_Click(object sender, EventArgs e)
        {
            port2.Write("j");
            btnPurging.Visible = true;
            btnOffPurging.Visible = false;
        }
    }
}
